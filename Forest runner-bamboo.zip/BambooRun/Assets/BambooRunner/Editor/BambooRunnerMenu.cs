#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

namespace BambooRunnerEditor
{
    [InitializeOnLoad]
    public static class BambooRunnerMenu
    {
        static BambooRunnerMenu()
        {
            string key = "BambooRun.shaders." + Application.dataPath;
            if (EditorPrefs.GetBool(key, false)) return;
            EditorApplication.delayCall += () => { if (AddShaders()) EditorPrefs.SetBool(key, true); };
        }

        [MenuItem("Bamboo Run/Add Shaders To Builds")]
        public static void AddShadersMenu() { AddShaders(); }

        static bool AddShaders()
        {
            try
            {
                var gs = AssetDatabase.LoadAssetAtPath<GraphicsSettings>("ProjectSettings/GraphicsSettings.asset");
                if (gs == null) return false;
                var so = new SerializedObject(gs);
                var arr = so.FindProperty("m_AlwaysIncludedShaders");
                if (arr == null) return false;
                string[] names = { "Sprites/Default", "Standard", "Universal Render Pipeline/Lit" };
                foreach (var n in names)
                {
                    var sh = Shader.Find(n);
                    if (sh == null) continue;
                    bool has = false;
                    for (int i = 0; i < arr.arraySize; i++)
                        if (arr.GetArrayElementAtIndex(i).objectReferenceValue == sh) { has = true; break; }
                    if (has) continue;
                    arr.arraySize++;
                    arr.GetArrayElementAtIndex(arr.arraySize - 1).objectReferenceValue = sh;
                }
                so.ApplyModifiedProperties();
                AssetDatabase.SaveAssets();
                return true;
            }
            catch (System.Exception e) { Debug.LogWarning("Bamboo Run: could not add shaders: " + e.Message); return false; }
        }

        [MenuItem("Bamboo Run/Create Game Scene")]
        public static void CreateScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var cam = new GameObject("Main Camera");
            cam.tag = "MainCamera";
            cam.AddComponent<Camera>();
            cam.AddComponent<AudioListener>();
            string dir = "Assets/BambooRunner/Scenes";
            if (!AssetDatabase.IsValidFolder(dir)) AssetDatabase.CreateFolder("Assets/BambooRunner", "Scenes");
            string path = dir + "/BambooRun.unity";
            EditorSceneManager.SaveScene(scene, path);
            var list = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
            bool found = false;
            foreach (var s in list) if (s.path == path) found = true;
            if (!found) list.Insert(0, new EditorBuildSettingsScene(path, true));
            EditorBuildSettings.scenes = list.ToArray();
            EditorUtility.DisplayDialog("Bamboo Run", "Scene created and added to Build Settings.\nPress Play!", "OK");
        }
    }
}
#endif
