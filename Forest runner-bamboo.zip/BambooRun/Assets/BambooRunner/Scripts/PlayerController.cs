using UnityEngine;

namespace BambooRunner
{
    /// <summary>
    /// The runner: a traveller with a straw hat, built from primitives and animated procedurally.
    /// The player stays at z = 0; the world scrolls toward the camera.
    /// </summary>
    public class PlayerController : MonoBehaviour
    {
        public const float StandH = 1.7f, SlideH = 0.75f;

        public float x, y, vy;
        public int lane;
        public bool grounded = true, sliding, dead;
        public float Height { get { return sliding ? SlideH : StandH; } }
        public System.Action<SwipeDir> Acted;

        Transform model, armL, armR, legL, legR, sc1, sc2, sc3, shield;
        float slideT, phase, deadT, shieldPulse, breakT;
        bool queuedSlide, shieldOn;
        int lastStep;
        Camera cam;

        // ---------------- selectable characters
        public static readonly string[] CharNames = { "Kai", "Mei", "Master Lin", "Shadow" };
        public static readonly string[] CharDesc =
        {
            "A brave boy in a straw hat",
            "A swift girl with flowing hair",
            "A calm monk with prayer beads",
            "A silent forest ninja"
        };
        static Color C(float r, float g, float b) { return new Color(r, g, b); }
        // tunic, trousers, sash, scarf, hair, skin
        static readonly Color[][] Pal =
        {
            new[] { C(.20f,.42f,.88f), C(.45f,.32f,.20f), C(.95f,.60f,.15f), C(.90f,.20f,.15f), C(.07f,.05f,.05f), C(.93f,.74f,.55f) },
            new[] { C(.92f,.28f,.48f), C(.96f,.94f,.90f), C(1.0f,.85f,.30f), C(.15f,.78f,.80f), C(.12f,.07f,.05f), C(.96f,.78f,.62f) },
            new[] { C(1.0f,.55f,.05f), C(.45f,.10f,.10f), C(.40f,.25f,.10f), C(.95f,.90f,.75f), C(.07f,.05f,.05f), C(.85f,.65f,.45f) },
            new[] { C(.10f,.12f,.20f), C(.16f,.16f,.19f), C(.80f,.10f,.10f), C(.85f,.12f,.12f), C(.06f,.07f,.12f), C(.90f,.72f,.55f) },
        };
        static readonly float[] BodyW = { 1.0f, 0.86f, 1.2f, 0.95f };
        // parts that are only visible for certain characters
        static readonly string[] Optional = { "Hat", "Hair", "HairLong", "Skirt", "Robe", "Beads", "Hood", "Headband", "Flower", "Pack", "PackStick" };
        static readonly string[][] Visible =
        {
            new[] { "Hat", "Hair", "Pack", "PackStick" },
            new[] { "Hair", "HairLong", "Skirt", "Flower" },
            new[] { "Robe", "Beads" },
            new[] { "Hood", "Headband", "PackStick" },
        };
        Material[][] charMats = new Material[4][];
        MeshRenderer[] allRends;
        Transform hairPivot;
        public int CharIndex { get; private set; }

        public void Build(Camera c)
        {
            cam = c;
            Mesh cap = Art.Prim(PrimitiveType.Capsule);
            Mesh sph = Art.Prim(PrimitiveType.Sphere);
            Mesh cube = Art.Prim(PrimitiveType.Cube);

            model = Pivot("Model", transform, new Vector3(0f, 0.85f, 0f));

            Art.Part("Torso", cap, Art.tunicMat, model, new Vector3(0f, 0.36f, 0f), new Vector3(0.40f, 0.30f, 0.28f));
            Art.Part("Sash", cube, Art.sashMat, model, new Vector3(0f, 0.10f, 0f), new Vector3(0.43f, 0.08f, 0.31f));
            Art.Part("Head", sph, Art.skinMat, model, new Vector3(0f, 0.86f, 0f), Vector3.one * 0.31f);
            Art.Part("Hair", sph, Art.hairMat, model, new Vector3(0f, 0.85f, -0.03f), new Vector3(0.33f, 0.29f, 0.33f));
            Art.Part("Hat", Art.Cone, Art.strawMat, model, new Vector3(0f, 0.96f, 0f), new Vector3(0.40f, 0.22f, 0.40f), new Vector3(-4f, 0f, 0f));
            Art.Part("EyeL", sph, Art.eyeMat, model, new Vector3(-0.055f, 0.88f, 0.135f), Vector3.one * 0.045f);
            Art.Part("EyeR", sph, Art.eyeMat, model, new Vector3(0.055f, 0.88f, 0.135f), Vector3.one * 0.045f);
            Art.Part("Pack", cube, Art.packMat, model, new Vector3(0f, 0.38f, -0.20f), new Vector3(0.34f, 0.42f, 0.16f));
            Art.Part("PackStick", Art.Prim(PrimitiveType.Cylinder), Art.cutBamboo, model, new Vector3(0.10f, 0.72f, -0.20f),
                new Vector3(0.05f, 0.30f, 0.05f), new Vector3(10f, 0f, -12f));

            // ---- extra parts used by individual characters
            Art.Part("Skirt", Art.Cone, Art.tunicMat, model, new Vector3(0f, -0.30f, 0f), new Vector3(0.50f, 0.46f, 0.50f));
            Art.Part("Robe", Art.Cone, Art.tunicMat, model, new Vector3(0f, -0.52f, 0f), new Vector3(0.50f, 0.76f, 0.50f));
            for (int i = 0; i < 6; i++)
                Art.Part("Beads", sph, Art.darkWood, model, new Vector3((i - 2.5f) * 0.075f, 0.52f + Mathf.Abs(i - 2.5f) * 0.045f, 0.16f), Vector3.one * 0.06f);
            Art.Part("Hood", sph, Art.hairMat, model, new Vector3(0f, 0.87f, -0.04f), new Vector3(0.345f, 0.33f, 0.34f));
            Art.Part("Headband", Art.Prim(PrimitiveType.Cylinder), Art.sashMat, model, new Vector3(0f, 0.93f, 0f), new Vector3(0.33f, 0.02f, 0.33f));
            Art.Part("Flower", sph, Art.flowerMat, model, new Vector3(0.12f, 0.97f, 0.08f), Vector3.one * 0.09f);
            hairPivot = Pivot("HairPivot", model, new Vector3(0f, 0.90f, -0.10f));
            Art.Part("HairLong", cap, Art.hairMat, hairPivot, new Vector3(0f, -0.20f, -0.03f), new Vector3(0.30f, 0.26f, 0.20f));

            armL = Pivot("ArmL", model, new Vector3(-0.26f, 0.62f, 0f));
            armR = Pivot("ArmR", model, new Vector3(0.26f, 0.62f, 0f));
            foreach (var a in new[] { armL, armR })
            {
                Art.Part("Arm", cap, Art.tunicMat, a, new Vector3(0f, -0.20f, 0f), new Vector3(0.12f, 0.22f, 0.12f));
                Art.Part("Hand", sph, Art.skinMat, a, new Vector3(0f, -0.44f, 0f), Vector3.one * 0.10f);
            }
            legL = Pivot("LegL", model, new Vector3(-0.10f, 0f, 0f));
            legR = Pivot("LegR", model, new Vector3(0.10f, 0f, 0f));
            foreach (var l in new[] { legL, legR })
            {
                Art.Part("Leg", cap, Art.trouserMat, l, new Vector3(0f, -0.38f, 0f), new Vector3(0.17f, 0.38f, 0.17f));
                Art.Part("Shoe", cube, Art.shoeMat, l, new Vector3(0f, -0.77f, 0.05f), new Vector3(0.17f, 0.10f, 0.28f));
            }

            // flowing scarf
            sc1 = Pivot("Scarf1", model, new Vector3(0f, 0.68f, -0.10f));
            Art.Part("S1", cube, Art.scarfMat, sc1, new Vector3(0f, 0f, -0.14f), new Vector3(0.12f, 0.05f, 0.28f));
            sc2 = Pivot("Scarf2", sc1, new Vector3(0f, 0f, -0.28f));
            Art.Part("S2", cube, Art.scarfMat, sc2, new Vector3(0f, 0f, -0.14f), new Vector3(0.11f, 0.04f, 0.28f));
            sc3 = Pivot("Scarf3", sc2, new Vector3(0f, 0f, -0.28f));
            Art.Part("S3", cube, Art.scarfMat, sc3, new Vector3(0f, 0f, -0.14f), new Vector3(0.10f, 0.035f, 0.28f));

            // shield bubble (billboard)
            var sg = Art.Part("Shield", Art.Prim(PrimitiveType.Quad), Art.shieldBubbleMat, transform, new Vector3(0f, 0.95f, 0f),
                Vector3.one * 2.5f, default(Vector3), false);
            shield = sg.transform;
            shield.gameObject.SetActive(false);

            allRends = model.GetComponentsInChildren<MeshRenderer>(true);
            SetCharacter(PlayerPrefs.GetInt("br_char", 0));
            ResetPlayer();
        }

        public void SetCharacter(int idx)
        {
            idx = ((idx % CharNames.Length) + CharNames.Length) % CharNames.Length;
            CharIndex = idx;
            if (charMats[idx] == null)
            {
                var m = new Material[6];
                for (int i = 0; i < 6; i++) m[i] = Art.Mat(Pal[idx][i], i == 5 ? 0.25f : 0.15f);
                charMats[idx] = m;
            }
            var mats = charMats[idx];
            foreach (var r in allRends)
            {
                string n = r.gameObject.name;
                switch (n)
                {
                    case "Torso":
                        r.sharedMaterial = mats[0];
                        r.transform.localScale = new Vector3(0.40f * BodyW[idx], 0.30f, 0.28f * BodyW[idx]);
                        break;
                    case "Arm": case "Skirt": case "Robe": r.sharedMaterial = mats[0]; break;
                    case "Leg": r.sharedMaterial = mats[1]; break;
                    case "Sash": case "Headband": r.sharedMaterial = mats[2]; break;
                    case "S1": case "S2": case "S3": r.sharedMaterial = mats[3]; break;
                    case "Hair": case "HairLong": case "Hood": r.sharedMaterial = mats[4]; break;
                    case "Head": case "Hand": r.sharedMaterial = mats[5]; break;
                }
                if (System.Array.IndexOf(Optional, n) >= 0)
                    r.gameObject.SetActive(System.Array.IndexOf(Visible[idx], n) >= 0);
            }
        }

        static Transform Pivot(string n, Transform parent, Vector3 pos)
        {
            var g = new GameObject(n).transform;
            g.SetParent(parent, false);
            g.localPosition = pos;
            return g;
        }

        public void ResetPlayer()
        {
            x = 0f; y = 0f; vy = 0f; lane = 0;
            grounded = true; sliding = false; dead = false; queuedSlide = false;
            slideT = 0f; deadT = 0f;
            transform.position = Vector3.zero;
            if (model != null)
            {
                model.localPosition = new Vector3(0f, 0.85f, 0f);
                model.localRotation = Quaternion.identity;
            }
            SetShield(false);
        }

        public void SetShield(bool on)
        {
            shieldOn = on;
            if (shield != null && breakT <= 0f) shield.gameObject.SetActive(on);
        }

        public void BreakShield()
        {
            shieldOn = false;
            breakT = 0.3f;
            if (shield != null) shield.gameObject.SetActive(true);
        }

        public void Kill() { dead = true; deadT = 0f; sliding = false; }

        public void Revive()
        {
            dead = false; deadT = 0f;
            y = 0f; vy = 0f; grounded = true; sliding = false;
            if (model != null)
            {
                model.localPosition = new Vector3(0f, 0.85f, 0f);
                model.localRotation = Quaternion.identity;
            }
        }

        // ------------------------------------------------------------------ input
        public void Command(SwipeDir d)
        {
            if (dead) return;
            var audio = AudioManager.I;
            switch (d)
            {
                case SwipeDir.Left:
                    if (lane > -1) { lane--; if (audio) audio.Play(Sfx.Lane, 1.1f, 0.6f); Fire(d); }
                    break;
                case SwipeDir.Right:
                    if (lane < 1) { lane++; if (audio) audio.Play(Sfx.Lane, 0.95f, 0.6f); Fire(d); }
                    break;
                case SwipeDir.Up:
                    if (grounded)
                    {
                        vy = 9.3f; grounded = false; sliding = false; queuedSlide = false;
                        if (audio) audio.Play(Sfx.Jump);
                        Fire(d);
                    }
                    break;
                case SwipeDir.Down:
                    if (grounded) StartSlide();
                    else { vy = -19f; queuedSlide = true; }
                    break;
            }
        }

        void Fire(SwipeDir d) { if (Acted != null) Acted(d); }

        void StartSlide()
        {
            sliding = true;
            slideT = 0.8f;
            queuedSlide = false;
            if (AudioManager.I) AudioManager.I.Play(Sfx.Slide);
            Fire(SwipeDir.Down);
        }

        // ------------------------------------------------------------------ update
        public void Tick(float dt, bool playing, float speed)
        {
            float k = 1f - Mathf.Exp(-18f * dt);

            if (dead)
            {
                deadT += dt;
                float f = Mathf.Clamp01(deadT / 0.35f);
                model.localRotation = Quaternion.Slerp(model.localRotation, Quaternion.Euler(85f, 0f, 0f), 1f - Mathf.Exp(-14f * dt));
                model.localPosition = Vector3.Lerp(model.localPosition, new Vector3(0f, 0.28f, 0f), 1f - Mathf.Exp(-12f * dt));
                armL.localRotation = Quaternion.Euler(-140f * f, 0f, 25f * f);
                armR.localRotation = Quaternion.Euler(-120f * f, 0f, -25f * f);
                legL.localRotation = Quaternion.Euler(20f * f, 0f, 0f);
                legR.localRotation = Quaternion.Euler(-30f * f, 0f, 0f);
                if (shield != null) shield.gameObject.SetActive(false);
                return;
            }

            // lanes
            float tx = lane * WorldGenerator.LaneW;
            float prevX = x;
            x = Mathf.MoveTowards(x, tx, (13f + speed * 0.35f) * dt);

            // vertical
            if (playing)
            {
                if (!grounded)
                {
                    vy -= 26f * dt;
                    y += vy * dt;
                    if (y <= 0f)
                    {
                        y = 0f; vy = 0f; grounded = true;
                        if (AudioManager.I) AudioManager.I.Play(Sfx.Land, 1f, 0.7f);
                        if (queuedSlide) StartSlide();
                    }
                }
                if (sliding)
                {
                    slideT -= dt;
                    if (slideT <= 0f) sliding = false;
                }
            }
            transform.position = new Vector3(x, y, 0f);

            // ---------- animation
            float animSpeed = playing ? speed : 6f;
            phase += 2f * Mathf.PI * Mathf.Min(animSpeed * 0.14f, 3.3f) * dt;
            float r = Mathf.Sin(phase);

            float pitch = 8f, ty = 0.85f + Mathf.Abs(r) * 0.05f;
            float legLx = r * 55f, legRx = -r * 55f, armLx = -r * 50f, armRx = r * 50f;
            float armZ = 8f;

            if (playing && !grounded)
            {
                pitch = 0f; ty = 0.85f;
                legLx = 40f; legRx = -25f;
                armLx = -150f; armRx = -150f; armZ = 18f;
            }
            else if (playing && sliding)
            {
                pitch = -78f; ty = 0.32f;
                legLx = 0f; legRx = 0f;
                armLx = 160f; armRx = 160f; armZ = 10f;
            }

            float roll = -(tx - x) * 7f;
            model.localRotation = Quaternion.Slerp(model.localRotation, Quaternion.Euler(pitch, 0f, roll), k);
            Vector3 mp = model.localPosition;
            mp.y = Mathf.Lerp(mp.y, ty, k);
            model.localPosition = mp;

            legL.localRotation = Quaternion.Slerp(legL.localRotation, Quaternion.Euler(legLx, 0f, 0f), k);
            legR.localRotation = Quaternion.Slerp(legR.localRotation, Quaternion.Euler(legRx, 0f, 0f), k);
            armL.localRotation = Quaternion.Slerp(armL.localRotation, Quaternion.Euler(armLx, 0f, armZ), k);
            armR.localRotation = Quaternion.Slerp(armR.localRotation, Quaternion.Euler(armRx, 0f, -armZ), k);

            // scarf flutter
            float t = Time.time;
            sc1.localRotation = Quaternion.Euler(-12f + Mathf.Sin(t * 9f) * 8f, Mathf.Sin(t * 5f) * 10f, 0f);
            sc2.localRotation = Quaternion.Euler(Mathf.Sin(t * 9f + 1f) * 14f, Mathf.Sin(t * 5f + 1f) * 16f, 0f);
            sc3.localRotation = Quaternion.Euler(Mathf.Sin(t * 9f + 2f) * 18f, Mathf.Sin(t * 5f + 2f) * 22f, 0f);
            if (hairPivot != null) hairPivot.localRotation = Quaternion.Euler(10f + Mathf.Sin(t * 7f) * (playing ? 8f : 3f), Mathf.Sin(t * 4f) * 5f, 0f);

            // footsteps
            if (playing && grounded && !sliding)
            {
                int step = Mathf.FloorToInt(phase / Mathf.PI);
                if (step != lastStep)
                {
                    lastStep = step;
                    if (AudioManager.I) AudioManager.I.Play(Sfx.Step, Random.Range(0.9f, 1.15f), 0.45f);
                }
            }

            // shield bubble
            if (shield != null)
            {
                if (breakT > 0f)
                {
                    breakT -= dt;
                    shield.localScale = Vector3.one * Mathf.Lerp(4.5f, 2.5f, Mathf.Clamp01(breakT / 0.3f));
                    if (breakT <= 0f) shield.gameObject.SetActive(shieldOn);
                }
                else if (shieldOn)
                {
                    shieldPulse += dt * 5f;
                    shield.localScale = Vector3.one * (2.5f + Mathf.Sin(shieldPulse) * 0.08f);
                }
                if (shield.gameObject.activeSelf && cam != null)
                {
                    shield.rotation = cam.transform.rotation;
                    shield.localPosition = new Vector3(0f, sliding ? 0.5f : 0.95f, 0f);
                }
            }
        }
    }
}
