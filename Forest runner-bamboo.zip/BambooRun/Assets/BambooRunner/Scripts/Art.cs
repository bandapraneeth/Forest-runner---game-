using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace BambooRunner
{
    /// <summary>
    /// Everything visual is generated in code: textures, materials and meshes.
    /// Works with the Built-in pipeline (Standard shader) and URP (Lit shader).
    /// </summary>
    public static class Art
    {
        public static int Quality = 1; // 0 = low (mobile), 1 = high (desktop)

        static Shader _lit, _unlit;
        static readonly Dictionary<PrimitiveType, Mesh> _prim = new Dictionary<PrimitiveType, Mesh>();
        static bool inited;

        public static Material groundMat, cutBamboo, darkWood, rockMat, mossMat, stoneMat, stoneRoofMat, ropeMat, bannerMat,
            strawMat, tunicMat, sashMat, trouserMat, skinMat, scarfMat, hairMat, shoeMat, packMat, eyeMat,
            goldMat, goldDarkMat, jadeMat, lanternMat, lanternWinMat, magnetMat, silverMat, shieldPlateMat, whiteGlowMat,
            orangeGlowMat, greenGlowMat, shaftMat, fxMat, leafPartMat, shieldBubbleMat,
            haloRed, haloCyan, haloOrange, haloGreen,
            barkMat, shrubMat, shrubMat2, flowerMat, stumpTopMat, mushCapMat;
        public static Material[][] StalkCombos;
        public static Material[] LeafMats;
        public static Mesh[] NearStalks, FarStalks, Ferns;
        public static Mesh Cone;
        public static Texture2D CoinIcon;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            _lit = null; _unlit = null; _prim.Clear(); inited = false;
        }

        // ------------------------------------------------------------------ shaders & helpers
        public static Shader Lit
        {
            get
            {
                if (_lit != null) return _lit;
                bool srp = GraphicsSettings.currentRenderPipeline != null;
                if (srp) _lit = Shader.Find("Universal Render Pipeline/Lit");
                if (_lit == null) _lit = Shader.Find("Standard");
                if (_lit == null) _lit = Shader.Find("Universal Render Pipeline/Lit");
                if (_lit == null) _lit = Shader.Find("Sprites/Default");
                return _lit;
            }
        }

        public static Shader Unlit
        {
            get
            {
                if (_unlit == null) _unlit = Shader.Find("Sprites/Default");
                if (_unlit == null) _unlit = Lit;
                return _unlit;
            }
        }

        public static Mesh Prim(PrimitiveType t)
        {
            Mesh m;
            if (_prim.TryGetValue(t, out m) && m != null) return m;
            var g = GameObject.CreatePrimitive(t);
            m = g.GetComponent<MeshFilter>().sharedMesh;
            g.SetActive(false);
            UnityEngine.Object.Destroy(g);
            _prim[t] = m;
            return m;
        }

        public static Material Mat(Color c, float smooth = 0.2f, Texture tex = null, float metal = 0f)
        {
            var m = new Material(Lit);
            m.color = c;
            if (tex != null) m.mainTexture = tex;
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metal);
            m.enableInstancing = true;
            return m;
        }

        public static Material Glow(Color c, float intensity = 1.2f, float smooth = 0.5f)
        {
            var m = Mat(c, smooth);
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", c * intensity);
            m.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            return m;
        }

        /// <summary>Unlit, alpha-blended, double sided material (halos, light shafts, particles).</summary>
        public static Material Alpha(Color c, Texture tex = null)
        {
            var m = new Material(Unlit);
            m.color = c;
            if (tex != null) m.mainTexture = tex;
            return m;
        }

        public static GameObject Part(string name, Mesh mesh, Material mat, Transform parent, Vector3 pos, Vector3 scale,
            Vector3 euler = default(Vector3), bool shadow = true)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localScale = scale;
            go.transform.localEulerAngles = euler;
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            var r = go.AddComponent<MeshRenderer>();
            r.sharedMaterial = mat;
            if (!shadow) r.shadowCastingMode = ShadowCastingMode.Off;
            return go;
        }

        // ------------------------------------------------------------------ init
        public static void Init()
        {
            if (inited) return;
            inited = true;

            var bamboo = BambooTex(false);
            var dry = BambooTex(true);
            var leafT = LeafTex();

            var stalk = new Material[]
            {
                Mat(Color.white, 0.35f, bamboo),
                Mat(new Color(0.92f, 1f, 0.72f), 0.35f, bamboo),
                Mat(new Color(0.78f, 0.97f, 0.90f), 0.35f, bamboo)
            };
            LeafMats = new Material[] { Mat(Color.white, 0.12f, leafT), Mat(new Color(1f, 0.96f, 0.62f), 0.12f, leafT) };
            StalkCombos = new Material[6][];
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 2; j++)
                    StalkCombos[i * 2 + j] = new Material[] { stalk[i], LeafMats[j] };

            groundMat = Mat(Color.white, 0.02f, GroundTex());
            cutBamboo = Mat(Color.white, 0.3f, dry);
            darkWood = Mat(new Color(0.30f, 0.20f, 0.12f), 0.1f);
            rockMat = Mat(new Color(0.42f, 0.45f, 0.40f), 0.08f);
            mossMat = Mat(new Color(0.25f, 0.46f, 0.15f), 0.05f);
            stoneMat = Mat(new Color(0.58f, 0.59f, 0.55f), 0.1f);
            stoneRoofMat = Mat(new Color(0.34f, 0.36f, 0.35f), 0.1f);
            ropeMat = Mat(new Color(0.40f, 0.28f, 0.16f), 0.05f);
            bannerMat = Mat(new Color(0.78f, 0.12f, 0.10f), 0.1f);

            barkMat = Mat(Color.white, 0.05f, BarkTex());
            shrubMat = Mat(new Color(0.17f, 0.40f, 0.12f), 0.08f);
            shrubMat2 = Mat(new Color(0.28f, 0.54f, 0.17f), 0.08f);
            flowerMat = Mat(new Color(0.95f, 0.35f, 0.55f), 0.2f);
            stumpTopMat = Mat(new Color(0.78f, 0.62f, 0.40f), 0.05f);
            mushCapMat = Mat(new Color(0.85f, 0.15f, 0.12f), 0.2f);
            strawMat = Mat(Color.white, 0.1f, StrawTex());
            tunicMat = Mat(new Color(0.88f, 0.22f, 0.14f), 0.15f);
            sashMat = Mat(new Color(0.95f, 0.78f, 0.20f), 0.2f);
            trouserMat = Mat(new Color(0.92f, 0.88f, 0.74f), 0.1f);
            skinMat = Mat(new Color(0.93f, 0.74f, 0.55f), 0.25f);
            scarfMat = Mat(new Color(0.10f, 0.72f, 0.70f), 0.2f);
            hairMat = Mat(new Color(0.07f, 0.05f, 0.05f), 0.3f);
            shoeMat = Mat(new Color(0.25f, 0.16f, 0.10f), 0.1f);
            packMat = Mat(Color.white, 0.1f, StrawTex());
            eyeMat = Mat(new Color(0.03f, 0.03f, 0.03f), 0.6f);

            goldMat = Mat(new Color(1f, 0.78f, 0.18f), 0.75f, null, 0.6f);
            goldMat.EnableKeyword("_EMISSION");
            goldMat.SetColor("_EmissionColor", new Color(1f, 0.65f, 0.1f) * 0.45f);
            goldDarkMat = Mat(new Color(0.50f, 0.33f, 0.04f), 0.4f);
            jadeMat = Glow(new Color(0.20f, 1f, 0.52f), 0.9f, 0.8f);
            lanternMat = Glow(new Color(1f, 0.32f, 0.10f), 1.4f, 0.4f);
            lanternWinMat = Glow(new Color(1f, 0.72f, 0.28f), 2.0f, 0.4f);
            magnetMat = Mat(new Color(0.90f, 0.10f, 0.10f), 0.6f);
            silverMat = Mat(new Color(0.85f, 0.87f, 0.90f), 0.85f, null, 0.8f);
            shieldPlateMat = Glow(new Color(0.20f, 0.80f, 1f), 1f, 0.7f);
            whiteGlowMat = Glow(Color.white, 1f, 0.7f);
            orangeGlowMat = Glow(new Color(1f, 0.55f, 0.10f), 1.2f, 0.6f);
            greenGlowMat = Glow(new Color(0.30f, 1f, 0.40f), 1.2f, 0.6f);

            var halo = HaloTex();
            haloRed = Alpha(new Color(1f, 0.25f, 0.2f, 0.55f), halo);
            haloCyan = Alpha(new Color(0.25f, 0.85f, 1f, 0.55f), halo);
            haloOrange = Alpha(new Color(1f, 0.65f, 0.15f, 0.55f), halo);
            haloGreen = Alpha(new Color(0.35f, 1f, 0.45f, 0.55f), halo);
            fxMat = Alpha(Color.white, halo);
            shaftMat = Alpha(new Color(1f, 0.96f, 0.72f, 0.15f), ShaftTex());
            leafPartMat = Alpha(Color.white, LeafParticleTex());
            shieldBubbleMat = Alpha(new Color(0.45f, 0.92f, 1f, 0.95f), ShieldTex());
            CoinIcon = CoinIconTex();

            // meshes ---------------------------------------------------------------
            float[] hs = { 16f, 18.5f, 21f, 23f, 17.5f, 20f };
            float[] rs = { 0.110f, 0.130f, 0.100f, 0.140f, 0.120f, 0.115f };
            float[] ls = { 1.4f, 2.6f, 3.4f, 2.0f, 3.0f, 1.8f };
            int radialNear = Quality == 0 ? 6 : 8;
            NearStalks = new Mesh[6];
            for (int i = 0; i < 6; i++)
                NearStalks[i] = StalkMesh(100 + i, hs[i], rs[i], ls[i], radialNear, Quality == 0 ? 1 : 2, Quality == 0 ? 3 : 4);
            FarStalks = new Mesh[5];
            for (int i = 0; i < 5; i++)
                FarStalks[i] = StalkMesh(200 + i, hs[i], rs[i] * 1.1f, ls[i] * 0.8f, 5, 1, 3);
            Ferns = new Mesh[4];
            for (int i = 0; i < 4; i++) Ferns[i] = FernMesh(300 + i);
            Cone = ConeMesh(14);
        }

        // ------------------------------------------------------------------ noise
        static float Hash(int x, int y, int seed)
        {
            unchecked
            {
                int h = x * 374761393 + y * 668265263 + seed * 1442695041;
                h = (h ^ (h >> 13)) * 1274126177;
                h ^= h >> 16;
                return (h & 0xFFFFFF) / (float)0xFFFFFF;
            }
        }

        // value noise that tiles seamlessly in both directions (u,v in [0,1))
        static float PNoise(float u, float v, int period, int seed)
        {
            float x = u * period, y = v * period;
            int x0 = Mathf.FloorToInt(x), y0 = Mathf.FloorToInt(y);
            float fx = x - x0, fy = y - y0;
            fx = fx * fx * (3f - 2f * fx);
            fy = fy * fy * (3f - 2f * fy);
            int x1 = (x0 + 1) % period, y1 = (y0 + 1) % period;
            x0 %= period; y0 %= period;
            float a = Hash(x0, y0, seed), b = Hash(x1, y0, seed), c = Hash(x0, y1, seed), d = Hash(x1, y1, seed);
            return Mathf.Lerp(Mathf.Lerp(a, b, fx), Mathf.Lerp(c, d, fx), fy);
        }

        static float SStep(float a, float b, float x)
        {
            float t = Mathf.Clamp01((x - a) / (b - a));
            return t * t * (3f - 2f * t);
        }

        // ------------------------------------------------------------------ textures
        static Texture2D MakeTex(int w, int h, System.Func<int, int, Color32> f, bool mip, TextureWrapMode wrap)
        {
            var t = new Texture2D(w, h, TextureFormat.RGBA32, mip);
            var px = new Color32[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    px[y * w + x] = f(x, y);
            t.SetPixels32(px);
            t.wrapMode = wrap;
            t.filterMode = FilterMode.Bilinear;
            t.anisoLevel = 4;
            t.Apply(mip);
            return t;
        }

        static Texture2D BambooTex(bool dry)
        {
            Color dark = dry ? new Color(0.55f, 0.43f, 0.16f) : new Color(0.17f, 0.36f, 0.12f);
            Color light = dry ? new Color(0.86f, 0.74f, 0.38f) : new Color(0.40f, 0.62f, 0.22f);
            Color ridge = dry ? new Color(0.62f, 0.48f, 0.20f) : new Color(0.74f, 0.72f, 0.40f);
            Color ridge2 = dry ? new Color(0.45f, 0.33f, 0.12f) : new Color(0.58f, 0.60f, 0.28f);
            Color line = dry ? new Color(0.30f, 0.20f, 0.06f) : new Color(0.10f, 0.20f, 0.07f);
            return MakeTex(64, 256, (x, y) =>
            {
                float u = (x + 0.5f) / 64f, v = (y + 0.5f) / 256f;
                float streak = PNoise(u, v * 0.25f, 16, 11);
                float fine = PNoise(u, v * 0.5f, 32, 12);
                Color c = Color.Lerp(dark, light, 0.25f + 0.55f * streak + 0.2f * fine);
                c = Color.Lerp(c, Color.Lerp(light, Color.white, 0.25f), 0.22f * Mathf.Sin(v * Mathf.PI));
                float nd = Mathf.Min(v, 1f - v);
                if (nd < 0.055f) c = Color.Lerp(ridge, ridge2, PNoise(u, v, 16, 13));
                else if (nd < 0.075f) c = Color.Lerp(c, line, 0.7f);
                if (Hash(x, y, 14) > 0.985f) c = c * 0.7f;
                c.a = 1f;
                return c;
            }, true, TextureWrapMode.Repeat);
        }

        static Texture2D LeafTex()
        {
            return MakeTex(32, 128, (x, y) =>
            {
                float u = (x + 0.5f) / 32f, v = (y + 0.5f) / 128f;
                float e = Mathf.Abs(u - 0.5f) * 2f;
                Color c = Color.Lerp(new Color(0.16f, 0.40f, 0.11f), new Color(0.42f, 0.68f, 0.20f), 1f - e * 0.9f);
                c = Color.Lerp(c, new Color(0.13f, 0.32f, 0.09f), v * 0.5f);
                if (e < 0.07f) c = Color.Lerp(c, new Color(0.68f, 0.82f, 0.42f), 0.7f);
                if (v < 0.12f) c = Color.Lerp(c, new Color(0.62f, 0.66f, 0.25f), 0.5f);
                c.a = 1f;
                return c;
            }, true, TextureWrapMode.Clamp);
        }

        static Texture2D BarkTex()
        {
            return MakeTex(64, 64, (x, y) =>
            {
                float u = (x + 0.5f) / 64f, v = (y + 0.5f) / 64f;
                float st = PNoise(u, v * 0.2f, 12, 21);
                float fi = PNoise(u, v * 0.5f, 24, 22);
                Color c = Color.Lerp(new Color(0.20f, 0.13f, 0.08f), new Color(0.46f, 0.33f, 0.21f), 0.2f + 0.6f * st + 0.2f * fi);
                c.a = 1f;
                return c;
            }, true, TextureWrapMode.Repeat);
        }

        static Texture2D StrawTex()
        {
            return MakeTex(64, 64, (x, y) =>
            {
                bool a = ((x + y) % 8) < 3;
                bool b = ((x - y + 64) % 8) < 3;
                Color c = new Color(0.82f, 0.67f, 0.38f);
                if (a) c = new Color(0.60f, 0.46f, 0.22f);
                if (b) c = new Color(0.92f, 0.78f, 0.46f);
                return c;
            }, true, TextureWrapMode.Repeat);
        }

        static Texture2D GroundTex()
        {
            const int W = 768, H = 512;
            const float GW = 60f;
            return MakeTex(W, H, (x, y) =>
            {
                float u = (x + 0.5f) / W, v = (y + 0.5f) / H;
                float wx = (u - 0.5f) * GW;
                float n = PNoise(u, v, 8, 1) * 0.5f + PNoise(u, v, 16, 2) * 0.3f + PNoise(u, v, 64, 3) * 0.2f;
                float m = PNoise(u, v, 32, 4);
                float d = Mathf.Abs(wx) + (PNoise(u, v, 16, 9) - 0.5f) * 1.8f;
                float path = 1f - SStep(3.5f, 4.8f, d);
                Color dirt = Color.Lerp(new Color(0.34f, 0.25f, 0.16f), new Color(0.56f, 0.44f, 0.29f), n);
                Color moss = Color.Lerp(new Color(0.11f, 0.23f, 0.08f), new Color(0.30f, 0.46f, 0.17f), n * 0.7f + m * 0.3f);
                Color c = Color.Lerp(moss, dirt, path);
                c.a = 1f;
                return c;
            }, true, TextureWrapMode.Repeat);
        }

        static Texture2D ShaftTex()
        {
            return MakeTex(32, 128, (x, y) =>
            {
                float u = (x + 0.5f) / 32f, v = (y + 0.5f) / 128f;
                float a = Mathf.Pow(1f - Mathf.Abs(2f * u - 1f), 1.5f) * Mathf.Pow(Mathf.Sin(Mathf.PI * v), 0.8f);
                return new Color(1f, 1f, 1f, Mathf.Clamp01(a));
            }, false, TextureWrapMode.Clamp);
        }

        static Texture2D HaloTex()
        {
            return MakeTex(64, 64, (x, y) =>
            {
                float dx = (x - 31.5f) / 32f, dy = (y - 31.5f) / 32f;
                float r = Mathf.Sqrt(dx * dx + dy * dy);
                float a = Mathf.Clamp01(1f - r);
                return new Color(1f, 1f, 1f, a * a);
            }, false, TextureWrapMode.Clamp);
        }

        static Texture2D ShieldTex()
        {
            return MakeTex(64, 64, (x, y) =>
            {
                float dx = (x - 31.5f) / 32f, dy = (y - 31.5f) / 32f;
                float r = Mathf.Sqrt(dx * dx + dy * dy);
                float a = 0f;
                if (r < 1f) a = 0.10f + 0.85f * SStep(0.62f, 0.95f, r) * (1f - SStep(0.95f, 1f, r));
                return new Color(1f, 1f, 1f, a);
            }, false, TextureWrapMode.Clamp);
        }

        static Texture2D LeafParticleTex()
        {
            return MakeTex(32, 32, (x, y) =>
            {
                float dx = (x - 15.5f) / 11f, dy = (y - 15.5f) / 15f;
                float d = dx * dx + dy * dy;
                if (d > 1f) return new Color(1f, 1f, 1f, 0f);
                float shade = 0.82f + 0.18f * (1f - d);
                if (Mathf.Abs(dx) < 0.08f) shade *= 0.82f;
                return new Color(shade, shade, shade, 1f);
            }, false, TextureWrapMode.Clamp);
        }

        static Texture2D CoinIconTex()
        {
            return MakeTex(64, 64, (x, y) =>
            {
                float dx = x - 31.5f, dy = y - 31.5f;
                float r = Mathf.Sqrt(dx * dx + dy * dy);
                if (r > 30f) return new Color(0f, 0f, 0f, 0f);
                Color c = r > 25f ? new Color(0.72f, 0.45f, 0.05f) : new Color(1f, 0.80f, 0.20f);
                if (Mathf.Abs(dx) < 8f && Mathf.Abs(dy) < 8f) c = new Color(0.45f, 0.28f, 0.03f);
                c.a = 1f;
                return c;
            }, false, TextureWrapMode.Clamp);
        }

        // ------------------------------------------------------------------ mesh building
        class MB
        {
            public List<Vector3> v = new List<Vector3>();
            public List<Vector3> n = new List<Vector3>();
            public List<Vector2> uv = new List<Vector2>();
            public List<int> t0 = new List<int>();
            public List<int> t1 = new List<int>();

            public int Add(Vector3 p, Vector3 nn, Vector2 u)
            {
                v.Add(p); n.Add(nn); uv.Add(u);
                return v.Count - 1;
            }

            // adds a triangle, flipping the winding if needed so its front face looks toward 'want'
            public void Tri(List<int> t, int a, int b, int c, Vector3 want)
            {
                Vector3 nr = Vector3.Cross(v[b] - v[a], v[c] - v[a]);
                if (Vector3.Dot(nr, want) < 0f) { int tmp = b; b = c; c = tmp; }
                t.Add(a); t.Add(b); t.Add(c);
            }

            public Mesh Build(string name, bool two)
            {
                var m = new Mesh();
                m.name = name;
                if (v.Count > 65000) m.indexFormat = IndexFormat.UInt32;
                m.SetVertices(v);
                m.SetNormals(n);
                m.SetUVs(0, uv);
                if (two)
                {
                    m.subMeshCount = 2;
                    m.SetTriangles(t0, 0);
                    m.SetTriangles(t1, 1);
                }
                else m.SetTriangles(t0, 0);
                m.RecalculateBounds();
                return m;
            }
        }

        static Vector3 Axis(float h, float H, float lean, float wob)
        {
            float q = h / H;
            return new Vector3(lean * q * q, h, Mathf.Sin(h * 0.6f + wob) * 0.07f * q);
        }

        static float Rad(float h, float H, float r0)
        {
            return r0 * (1f - 0.62f * Mathf.Pow(Mathf.Clamp01(h / H), 0.85f));
        }

        // a drooping, double-sided leaf blade
        static void Leaf(MB mb, List<int> tris, Vector3 p, Vector3 dir, float len, float width, float droop, float lift, float roll)
        {
            dir.y = 0f;
            dir.Normalize();
            Vector3 right = Vector3.Cross(Vector3.up, dir);
            Vector3 rr = (right * Mathf.Cos(roll) + Vector3.up * Mathf.Sin(roll)).normalized;
            Vector3 nrm = Vector3.Cross(dir, rr).normalized;
            if (nrm.y < 0f) nrm = -nrm;

            float[] tt = { 0f, 0.35f, 0.7f, 1f };
            float[] ws = { 0.25f, 1f, 0.7f };
            Vector3[] c = new Vector3[4];
            for (int i = 0; i < 4; i++)
            {
                float t = tt[i];
                c[i] = p + dir * (len * t) + Vector3.up * (len * (lift * t - droop * t * t));
            }

            for (int side = 0; side < 2; side++)
            {
                Vector3 nn = side == 0 ? nrm : -nrm;
                int[] idx = new int[7];
                for (int i = 0; i < 3; i++)
                {
                    float w = width * ws[i] * 0.5f;
                    idx[i * 2] = mb.Add(c[i] - rr * w, nn, new Vector2(0f, tt[i]));
                    idx[i * 2 + 1] = mb.Add(c[i] + rr * w, nn, new Vector2(1f, tt[i]));
                }
                idx[6] = mb.Add(c[3], nn, new Vector2(0.5f, 1f));
                mb.Tri(tris, idx[0], idx[1], idx[2], nn);
                mb.Tri(tris, idx[1], idx[3], idx[2], nn);
                mb.Tri(tris, idx[2], idx[3], idx[4], nn);
                mb.Tri(tris, idx[3], idx[5], idx[4], nn);
                mb.Tri(tris, idx[4], idx[5], idx[6], nn);
            }
        }

        static float R01(System.Random r) { return (float)r.NextDouble(); }

        /// <summary>
        /// A single bamboo culm: tapered, with real node ridges every internode, a gentle bend
        /// and drooping leaf clusters in the upper half. Submesh 0 = stalk, submesh 1 = leaves.
        /// </summary>
        static Mesh StalkMesh(int seed, float H, float r0, float lean, int radial, int branches, int leavesPer)
        {
            var rnd = new System.Random(seed);
            var mb = new MB();
            int n = Mathf.Max(8, Mathf.RoundToInt(H / 1.3f));
            var len = new float[n];
            float sum = 0f;
            for (int i = 0; i < n; i++)
            {
                len[i] = 0.75f + 0.5f * Mathf.Sin(Mathf.PI * (i + 0.5f) / n);
                sum += len[i];
            }
            for (int i = 0; i < n; i++) len[i] *= H / sum;

            float wob = R01(rnd) * 6f;
            float h0 = 0f;
            float[] rv = { 0f, 0.07f, 0.93f, 1f };
            float[] rm = { 1.09f, 1f, 1f, 1.09f };

            for (int i = 0; i < n; i++)
            {
                var rings = new int[4][];
                var hh = new float[4];
                var rr = new float[4];
                for (int j = 0; j < 4; j++)
                {
                    hh[j] = h0 + len[i] * rv[j];
                    rr[j] = Rad(hh[j], H, r0) * rm[j];
                }
                for (int j = 0; j < 4; j++)
                {
                    int a = Mathf.Max(0, j - 1), b = Mathf.Min(3, j + 1);
                    float slope = (rr[b] - rr[a]) / Mathf.Max(0.001f, hh[b] - hh[a]);
                    rings[j] = new int[radial + 1];
                    Vector3 cen = Axis(hh[j], H, lean, wob);
                    for (int k = 0; k <= radial; k++)
                    {
                        float ang = 2f * Mathf.PI * k / radial;
                        Vector3 d = new Vector3(Mathf.Cos(ang), 0f, Mathf.Sin(ang));
                        Vector3 nrm = (d + Vector3.up * (-slope)).normalized;
                        rings[j][k] = mb.Add(cen + d * rr[j], nrm, new Vector2((float)k / radial, rv[j]));
                    }
                }
                for (int j = 0; j < 3; j++)
                    for (int k = 0; k < radial; k++)
                    {
                        int p0 = rings[j][k], p1 = rings[j][k + 1], q0 = rings[j + 1][k], q1 = rings[j + 1][k + 1];
                        mb.Tri(mb.t0, p0, q0, p1, mb.n[p0]);
                        mb.Tri(mb.t0, p1, q0, q1, mb.n[p0]);
                    }

                // leaves sprout from the nodes of the upper part of the culm
                if (i >= (int)(n * 0.42f) && i > 1)
                {
                    float t = (float)i / n;
                    for (int bI = 0; bI < branches; bI++)
                    {
                        float a = R01(rnd) * Mathf.PI * 2f;
                        Vector3 dir = new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a));
                        Vector3 bp = Axis(h0, H, lean, wob) + dir * (Rad(h0, H, r0) * 0.9f);
                        float baseLen = Mathf.Lerp(1.5f, 0.85f, t);
                        for (int l = 0; l < leavesPer; l++)
                        {
                            float la = a + (l - (leavesPer - 1) * 0.5f) * 0.38f + (R01(rnd) - 0.5f) * 0.2f;
                            Vector3 ld = new Vector3(Mathf.Cos(la), 0f, Mathf.Sin(la));
                            Leaf(mb, mb.t1, bp, ld, baseLen * (0.85f + R01(rnd) * 0.4f), 0.2f,
                                0.55f + R01(rnd) * 0.3f, 0.3f, (R01(rnd) - 0.5f) * 1.0f);
                        }
                    }
                }
                h0 += len[i];
            }
            return mb.Build("BambooStalk", true);
        }

        static Mesh FernMesh(int seed)
        {
            var rnd = new System.Random(seed);
            var mb = new MB();
            int fronds = 9;
            for (int f = 0; f < fronds; f++)
            {
                float a = f * (2f * Mathf.PI / fronds) + R01(rnd) * 0.4f;
                Vector3 dir = new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a));
                Leaf(mb, mb.t0, new Vector3(0f, 0.05f, 0f), dir, 0.9f + R01(rnd) * 0.5f, 0.38f, 0.9f, 0.9f, (R01(rnd) - 0.5f) * 0.6f);
            }
            return mb.Build("Fern", false);
        }

        // cone with apex up (radius 1, height 1, base at y=0), double sided
        static Mesh ConeMesh(int seg)
        {
            var mb = new MB();
            for (int s = 0; s < 2; s++)
            {
                float sg = s == 0 ? 1f : -1f;
                int[] b = new int[seg + 1];
                for (int k = 0; k <= seg; k++)
                {
                    float a = 2f * Mathf.PI * k / seg;
                    Vector3 d = new Vector3(Mathf.Cos(a), 0f, Mathf.Sin(a));
                    b[k] = mb.Add(d, new Vector3(d.x, 1f, d.z).normalized * sg, new Vector2((float)k / seg, 0f));
                }
                for (int k = 0; k < seg; k++)
                {
                    float am = 2f * Mathf.PI * (k + 0.5f) / seg;
                    Vector3 nm = new Vector3(Mathf.Cos(am), 1f, Mathf.Sin(am)).normalized * sg;
                    int apex = mb.Add(new Vector3(0f, 1f, 0f), nm, new Vector2((k + 0.5f) / seg, 1f));
                    mb.Tri(mb.t0, b[k], apex, b[k + 1], nm);
                }
            }
            return mb.Build("Cone", false);
        }
    }
}
