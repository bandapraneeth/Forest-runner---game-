using System.Collections.Generic;
using UnityEngine;

namespace BambooRunner
{
    public enum GameState { Menu, Playing, Paused, Dead }

    /// <summary>
    /// Creates the whole game at runtime: camera, lighting, world, player, audio and UI (OnGUI).
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager I;
        public const float StartSpeed = 12f, MaxSpeed = 29f;
        const float MagnetDur = 10f, DoubleDur = 12f, DashDur = 6f, ShieldDur = 25f;
        static readonly Color FogCol = new Color(0.66f, 0.82f, 0.70f);

        public GameState state = GameState.Menu;
        public AudioManager Audio;
        public WorldGenerator World;
        public PlayerController Player;

        Camera cam;
        Transform camT;
        Light sun;

        float speed, distance;
        int coinPoints, runCoins, runGems, bank, best, bestDist, revives;
        float magnetT, doubleT, dashT, shieldT, invulnT;
        int combo; float lastCoinT;
        float shakeT, shakeMag, deadT;
        int nextMilestone = 500;
        bool newBest;
        float fovCur = 64f;

        // ------------------------------------------------------------------ missions
        enum MK { Coins, Distance, Jumps, Slides, PowerUps, Gems, Score, Dashes, ShieldSaves, Lanes }
        class MDef
        {
            public string text; public MK kind; public int target, reward;
            public MDef(string t, MK k, int tg, int r) { text = t; kind = k; target = tg; reward = r; }
        }
        static readonly MDef[] Pool =
        {
            new MDef("Collect 40 coins in one run", MK.Coins, 40, 20),
            new MDef("Run 800 m in one run", MK.Distance, 800, 25),
            new MDef("Jump 15 times", MK.Jumps, 15, 15),
            new MDef("Slide 12 times", MK.Slides, 12, 15),
            new MDef("Grab 3 power-ups", MK.PowerUps, 3, 30),
            new MDef("Collect 2 jade gems", MK.Gems, 2, 35),
            new MDef("Score 3000 points", MK.Score, 3000, 40),
            new MDef("Use Jade Dash twice", MK.Dashes, 2, 40),
            new MDef("Block a hit with a shield", MK.ShieldSaves, 1, 30),
            new MDef("Change lanes 40 times", MK.Lanes, 40, 20),
            new MDef("Collect 100 coins in one run", MK.Coins, 100, 60),
            new MDef("Run 2000 m in one run", MK.Distance, 2000, 70),
            new MDef("Grab 6 power-ups", MK.PowerUps, 6, 60),
            new MDef("Score 10000 points", MK.Score, 10000, 90),
        };
        int[] stat = new int[10];
        int[] slot = new int[3];
        int[] baseline = new int[3];
        int mnext;
        float missionTimer;

        class Toast { public string s; public float t; public Color c; }
        readonly List<Toast> toasts = new List<Toast>();

        int Score { get { return Mathf.FloorToInt(distance) + coinPoints; } }

        // ------------------------------------------------------------------ lifecycle
        void Awake()
        {
            I = this;
            Application.targetFrameRate = 60;
            Art.Quality = Application.isMobilePlatform ? 0 : 1;
            Art.Init();
            SetupScene();

            Audio = new GameObject("Audio").AddComponent<AudioManager>();
            Audio.transform.SetParent(transform, false);

            World = new GameObject("WorldGen").AddComponent<WorldGenerator>();
            World.transform.SetParent(transform, false);
            World.Init(cam);

            Player = new GameObject("Player").AddComponent<PlayerController>();
            Player.transform.SetParent(transform, false);
            Player.Build(cam);
            Player.Acted = OnPlayerActed;

            LoadPrefs();
            selectedChar = Player.CharIndex;
            Audio.StartLoops();
            Audio.SetMuted(PlayerPrefs.GetInt("br_mute", 0) == 1);
            speed = 5f;
            camT.position = new Vector3(1.6f, 1.5f, 4.2f);
            camT.LookAt(new Vector3(0f, 1.2f, 0f));
        }

        void OnDestroy() { Time.timeScale = 1f; }

        void OnApplicationPause(bool paused)
        {
            if (paused) { Save(); if (state == GameState.Playing) Pause(); }
        }

        void OnApplicationQuit() { Save(); }

        void SetupScene()
        {
            cam = Camera.main;
            if (cam == null)
            {
                var cg = new GameObject("Main Camera");
                cg.tag = "MainCamera";
                cam = cg.AddComponent<Camera>();
            }
            if (cam.GetComponent<AudioListener>() == null) cam.gameObject.AddComponent<AudioListener>();
            camT = cam.transform;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = FogCol;
            cam.nearClipPlane = 0.2f;
            cam.farClipPlane = 170f;
            cam.fieldOfView = 64f;

            foreach (var l in Resources.FindObjectsOfTypeAll<Light>())
            {
                if (!l.gameObject.scene.IsValid() || !l.gameObject.scene.isLoaded) continue;
                if (l.type == LightType.Directional && sun == null) sun = l;
                else l.enabled = false;
            }
            if (sun == null)
            {
                var lg = new GameObject("BambooSun");
                sun = lg.AddComponent<Light>();
                sun.type = LightType.Directional;
            }
            sun.enabled = true;
            sun.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            sun.color = new Color(1f, 0.93f, 0.78f);
            sun.intensity = 1.25f;
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.8f;

            RenderSettings.skybox = null;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.50f, 0.62f, 0.52f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = FogCol;
            RenderSettings.fogStartDistance = 24f;
            RenderSettings.fogEndDistance = 140f;
            QualitySettings.shadowDistance = 45f;
        }

        // ------------------------------------------------------------------ persistence
        void LoadPrefs()
        {
            bank = PlayerPrefs.GetInt("br_bank", 0);
            best = PlayerPrefs.GetInt("br_best", 0);
            bestDist = PlayerPrefs.GetInt("br_bestDist", 0);
            mnext = PlayerPrefs.GetInt("br_mnext", 3);
            for (int i = 0; i < 3; i++) slot[i] = PlayerPrefs.GetInt("br_ms" + i, i) % Pool.Length;
        }

        void Save()
        {
            PlayerPrefs.SetInt("br_bank", bank);
            PlayerPrefs.SetInt("br_best", best);
            PlayerPrefs.SetInt("br_bestDist", bestDist);
            PlayerPrefs.SetInt("br_mnext", mnext);
            for (int i = 0; i < 3; i++) PlayerPrefs.SetInt("br_ms" + i, slot[i]);
            PlayerPrefs.SetInt("br_mute", Audio != null && Audio.Muted ? 1 : 0);
            PlayerPrefs.SetInt("br_char", selectedChar);
            PlayerPrefs.Save();
        }

        // ------------------------------------------------------------------ flow
        void StartRun()
        {
            state = GameState.Playing;
            distance = 0f; coinPoints = 0; runCoins = 0; runGems = 0; revives = 0;
            magnetT = doubleT = dashT = shieldT = invulnT = 0f;
            combo = 0; nextMilestone = 500; newBest = false;
            System.Array.Clear(stat, 0, stat.Length);
            for (int i = 0; i < 3; i++) baseline[i] = 0;
            toasts.Clear();
            World.ResetWorld(false);
            Player.ResetPlayer();
            Player.transform.rotation = Quaternion.identity;
            speed = StartSpeed * 0.6f;
            Audio.Play(Sfx.Click);
            GameInput.ResetSwipe();
        }

        void ReturnToMenu()
        {
            Time.timeScale = 1f;
            state = GameState.Menu;
            menuPage = 0;
            World.ResetWorld(true);
            Player.ResetPlayer();
            speed = 5f;
            Audio.Play(Sfx.Click);
        }

        void Pause()
        {
            state = GameState.Paused;
            Time.timeScale = 0f;
        }

        void Resume()
        {
            state = GameState.Playing;
            Time.timeScale = 1f;
            GameInput.ResetSwipe();
            Audio.Play(Sfx.Click);
        }

        void Die()
        {
            state = GameState.Dead;
            deadT = 0f;
            Player.Kill();
            Audio.Play(Sfx.Crash);
            Shake(0.5f, 0.5f);
            int sc = Score;
            if (sc > best) { best = sc; newBest = true; }
            if ((int)distance > bestDist) bestDist = (int)distance;
            Save();
        }

        void Revive()
        {
            int cost = 50 * (revives + 1);
            if (bank < cost || revives >= 2) return;
            bank -= cost;
            revives++;
            World.ClearAhead(90f);
            Player.Revive();
            invulnT = 3f;
            speed = StartSpeed * 0.5f;
            state = GameState.Playing;
            Audio.Play(Sfx.Revive);
            GameInput.ResetSwipe();
            Save();
        }

        void Shake(float t, float mag) { shakeT = t; shakeMag = mag; }

        void OnPlayerActed(SwipeDir d)
        {
            if (d == SwipeDir.Up) stat[(int)MK.Jumps]++;
            else if (d == SwipeDir.Down) stat[(int)MK.Slides]++;
            else if (d == SwipeDir.Left || d == SwipeDir.Right) stat[(int)MK.Lanes]++;
        }

        // ------------------------------------------------------------------ update
        void Update()
        {
            float dt = Mathf.Min(Time.deltaTime, 0.05f);

            if (GameInput.MutePressed()) { Audio.SetMuted(!Audio.Muted); Save(); }

            for (int i = toasts.Count - 1; i >= 0; i--)
            {
                toasts[i].t -= Time.unscaledDeltaTime;
                if (toasts[i].t <= 0f) toasts.RemoveAt(i);
            }

            switch (state)
            {
                case GameState.Menu: UpdateMenu(dt); break;
                case GameState.Playing: UpdatePlaying(dt); break;
                case GameState.Paused:
                    if (GameInput.PausePressed()) Resume();
                    break;
                case GameState.Dead: UpdateDead(dt); break;
            }
        }

        Rect soundRect;
        int menuPage; // 0 = home, 1 = how to play, 2 = choose runner
        int selectedChar;

        void UpdateMenu(float dt)
        {
            speed = 5f;
            World.Tick(dt, speed, 0f);
            Player.Tick(dt, false, speed);
            if (menuPage == 0 && GameInput.Confirm()) StartRun();
            else if (menuPage != 0 && GameInput.PausePressed()) CloseRunnerPage();
            // slowly turn the runner while choosing so you can see every side
            Player.transform.rotation = menuPage == 2 ? Quaternion.Euler(0f, Mathf.Sin(Time.time * 0.9f) * 40f, 0f) : Quaternion.identity;
        }

        void UpdatePlaying(float dt)
        {
            if (GameInput.PausePressed()) { Pause(); return; }

            SwipeDir sd = GameInput.Poll();
            if (sd != SwipeDir.None) Player.Command(sd);

            // timers
            magnetT = Mathf.Max(0f, magnetT - dt);
            doubleT = Mathf.Max(0f, doubleT - dt);
            invulnT = Mathf.Max(0f, invulnT - dt);
            if (shieldT > 0f) { shieldT -= dt; if (shieldT <= 0f) Player.SetShield(false); }
            if (dashT > 0f)
            {
                dashT -= dt;
                if (dashT <= 0f) { invulnT = Mathf.Max(invulnT, 0.9f); }
            }

            float baseSpeed = Mathf.Min(MaxSpeed, StartSpeed + distance * 0.005f);
            float target = baseSpeed * (dashT > 0f ? 1.7f : 1f);
            speed = Mathf.MoveTowards(speed, target, 25f * dt);
            distance += speed * dt;

            Player.Tick(dt, true, speed);
            World.Tick(dt, speed, distance);

            // obstacles
            bool invincible = dashT > 0f || invulnT > 0f;
            float sweep = speed * dt;
            if (invincible)
            {
                World.CheckHit(Player.x, Player.y, Player.Height, sweep, true);
            }
            else if (shieldT > 0f)
            {
                if (World.CheckHit(Player.x, Player.y, Player.Height, sweep, true))
                {
                    shieldT = 0f;
                    Player.BreakShield();
                    invulnT = 1.0f;
                    stat[(int)MK.ShieldSaves]++;
                    Audio.Play(Sfx.ShieldBreak);
                    Shake(0.25f, 0.25f);
                    AddToast("SHIELD SAVED YOU!", new Color(0.4f, 0.9f, 1f));
                }
            }
            else if (World.CheckHit(Player.x, Player.y, Player.Height, sweep, false))
            {
                Die();
                return;
            }

            // pickups
            World.Collect(Player.x, Player.y, Player.Height, sweep, magnetT > 0f, dt, OnCollect);

            // milestones & missions
            if (distance >= nextMilestone)
            {
                int reward = 10 + (nextMilestone / 500) * 5;
                bank += reward; runCoins += reward;
                AddToast(nextMilestone + " m!  +" + reward + " coins", new Color(1f, 0.9f, 0.4f));
                Audio.Play(Sfx.Reward, 1f, 0.8f);
                nextMilestone += 500;
            }
            stat[(int)MK.Distance] = (int)distance;
            stat[(int)MK.Score] = Score;
            missionTimer -= dt;
            if (missionTimer <= 0f) { missionTimer = 0.25f; CheckMissions(); }
        }

        void UpdateDead(float dt)
        {
            deadT += dt;
            speed = Mathf.MoveTowards(speed, 0f, 45f * dt);
            World.Tick(dt, speed, distance);
            Player.Tick(dt, false, speed);
            if (deadT > 0.9f)
            {
                if (GameInput.Confirm() || GameInput.RetryPressed()) StartRun();
            }
        }

        void OnCollect(WorldGenerator.ColType t, Vector3 pos)
        {
            switch (t)
            {
                case WorldGenerator.ColType.Coin:
                {
                    int v = doubleT > 0f ? 2 : 1;
                    runCoins += v; bank += v; coinPoints += 10 * v; stat[(int)MK.Coins] += v;
                    combo = (Time.time - lastCoinT < 0.7f) ? combo + 1 : 1;
                    lastCoinT = Time.time;
                    Audio.Play(Sfx.Coin, 1f + Mathf.Min(combo, 10) * 0.035f, 0.7f);
                    World.Burst(pos, new Color(1f, 0.85f, 0.25f), 4);
                    break;
                }
                case WorldGenerator.ColType.Gem:
                {
                    int v = 10 * (doubleT > 0f ? 2 : 1);
                    runCoins += v; bank += v; coinPoints += 50 * v / 10; runGems++;
                    stat[(int)MK.Gems]++; stat[(int)MK.Coins] += v;
                    Audio.Play(Sfx.Gem);
                    World.Burst(pos, new Color(0.3f, 1f, 0.55f), 14);
                    AddToast("JADE GEM  +" + v, new Color(0.4f, 1f, 0.6f));
                    break;
                }
                case WorldGenerator.ColType.Magnet:
                    magnetT = MagnetDur; PowerPicked(pos, new Color(1f, 0.3f, 0.25f), "COIN MAGNET!"); break;
                case WorldGenerator.ColType.Shield:
                    shieldT = ShieldDur; Player.SetShield(true); PowerPicked(pos, new Color(0.3f, 0.85f, 1f), "BAMBOO SHIELD!"); break;
                case WorldGenerator.ColType.Double:
                    doubleT = DoubleDur; PowerPicked(pos, new Color(1f, 0.65f, 0.2f), "DOUBLE COINS!"); break;
                case WorldGenerator.ColType.Dash:
                    dashT = DashDur; invulnT = Mathf.Max(invulnT, DashDur); stat[(int)MK.Dashes]++;
                    PowerPicked(pos, new Color(0.4f, 1f, 0.45f), "JADE DASH!"); break;
            }
        }

        void PowerPicked(Vector3 pos, Color c, string msg)
        {
            stat[(int)MK.PowerUps]++;
            Audio.Play(Sfx.Power);
            World.Burst(pos, c, 22);
            AddToast(msg, c);
        }

        void AddToast(string s, Color c)
        {
            toasts.Add(new Toast { s = s, t = 2.2f, c = c });
            if (toasts.Count > 4) toasts.RemoveAt(0);
        }

        // ------------------------------------------------------------------ missions
        void CheckMissions()
        {
            for (int i = 0; i < 3; i++)
            {
                var m = Pool[slot[i]];
                int prog = stat[(int)m.kind] - baseline[i];
                if (prog >= m.target)
                {
                    bank += m.reward;
                    runCoins += m.reward;
                    AddToast("MISSION COMPLETE!  +" + m.reward + " coins", new Color(1f, 0.85f, 0.3f));
                    Audio.Play(Sfx.Reward);
                    // next mission that isn't already in a slot
                    int guard = 0;
                    do { slot[i] = mnext % Pool.Length; mnext++; guard++; }
                    while (guard < 20 && (slot[i] == slot[(i + 1) % 3] || slot[i] == slot[(i + 2) % 3]));
                    baseline[i] = stat[(int)Pool[slot[i]].kind];
                    Save();
                }
            }
        }

        // ------------------------------------------------------------------ camera
        void LateUpdate()
        {
            float dt = Mathf.Min(Time.unscaledDeltaTime, 0.05f);
            if (state == GameState.Paused) dt = 0f;

            Vector3 desired, look;
            float fovT = 64f;
            if (state == GameState.Menu)
            {
                desired = new Vector3(1.7f, 1.5f, 4.3f);
                look = new Vector3(0f, 1.15f, 0f);
                fovT = 55f;
                if (menuPage == 2)
                {
                    desired = new Vector3(0.6f, 1.4f, 4.6f);
                    look = new Vector3(0f, 0.65f, 0f);
                    fovT = 50f;
                }
            }
            else
            {
                float px = Player.x;
                desired = new Vector3(px * 0.6f, 3.1f + Player.y * 0.4f, -6.6f);
                look = new Vector3(px * 0.5f, 1.5f + Player.y * 0.3f, 7f);
                fovT = 64f + speed * 0.18f + (dashT > 0f ? 12f : 0f);
            }
            if (cam.aspect < 1f) fovT += 14f;

            camT.position = Vector3.Lerp(camT.position, desired, 1f - Mathf.Exp(-6f * dt));
            Quaternion rot = Quaternion.LookRotation(look - camT.position);
            camT.rotation = Quaternion.Slerp(camT.rotation, rot, 1f - Mathf.Exp(-9f * dt));
            fovCur = Mathf.Lerp(fovCur, fovT, 1f - Mathf.Exp(-4f * dt));
            cam.fieldOfView = fovCur;

            if (shakeT > 0f)
            {
                shakeT -= dt;
                camT.position += Random.insideUnitSphere * shakeMag * Mathf.Clamp01(shakeT * 2f);
            }
        }

        // ------------------------------------------------------------------ UI
        GUIStyle label, button;

        void Txt(float x, float y, float w, float h, string s, int size, TextAnchor al, Color c)
        {
            label.fontSize = size; label.alignment = al; label.fontStyle = FontStyle.Bold;
            label.normal.textColor = new Color(0f, 0f, 0f, 0.65f);
            GUI.Label(new Rect(x + 2f, y + 2f, w, h), s, label);
            label.normal.textColor = c;
            GUI.Label(new Rect(x, y, w, h), s, label);
        }

        static void Box(float x, float y, float w, float h, Color c)
        {
            GUI.color = c;
            GUI.DrawTexture(new Rect(x, y, w, h), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        bool Btn(float x, float y, float w, float h, string s, int size = 28)
        {
            button.fontSize = size;
            bool r = GUI.Button(new Rect(x, y, w, h), s, button);
            if (r) Audio.Play(Sfx.Click);
            return r;
        }

        void OnGUI()
        {
            if (label == null)
            {
                label = new GUIStyle(GUI.skin.label);
                label.wordWrap = false;
                button = new GUIStyle(GUI.skin.button);
                button.fontStyle = FontStyle.Bold;
            }
            float s = Screen.height / 720f;
            GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
            float W = Screen.width / s, H = 720f;
            Color gold = new Color(1f, 0.85f, 0.3f);

            soundRect = new Rect(W - 190f, 14f, 80f, 46f);
            if (state != GameState.Dead || deadT > 0.9f)
            {
                if (Btn(soundRect.x, soundRect.y, soundRect.width, soundRect.height, Audio.Muted ? "OFF" : "SND", 22))
                { Audio.SetMuted(!Audio.Muted); Save(); }
            }

            switch (state)
            {
                case GameState.Menu: DrawMenu(W, H, gold); break;
                case GameState.Playing: DrawHud(W, H, gold); break;
                case GameState.Paused: DrawHud(W, H, gold); DrawPause(W, H, gold); break;
                case GameState.Dead:
                    DrawHud(W, H, gold);
                    if (deadT > 0.9f) DrawGameOver(W, H, gold);
                    break;
            }
        }

        void DrawHud(float W, float H, Color gold)
        {
            // coins
            GUI.DrawTexture(new Rect(20f, 14f, 40f, 40f), Art.CoinIcon);
            Txt(68f, 10f, 220f, 48f, runCoins.ToString(), 36, TextAnchor.MiddleLeft, gold);
            if (runGems > 0) Txt(20f, 56f, 260f, 30f, "Jade gems: " + runGems, 20, TextAnchor.MiddleLeft, new Color(0.4f, 1f, 0.6f));

            // score / distance
            Txt(W * 0.5f - 200f, 6f, 400f, 52f, Score.ToString(), 46, TextAnchor.MiddleCenter, Color.white);
            Txt(W * 0.5f - 200f, 54f, 400f, 30f, Mathf.FloorToInt(distance) + " m   x" + (doubleT > 0f ? "2" : "1"), 22, TextAnchor.MiddleCenter, new Color(0.85f, 1f, 0.85f));

            if (state == GameState.Playing && Btn(W - 100f, 14f, 80f, 46f, "II", 24)) Pause();

            // power-up bars
            float y = 98f;
            if (magnetT > 0f) { Bar(20f, y, "MAGNET", magnetT / MagnetDur, new Color(1f, 0.3f, 0.25f)); y += 34f; }
            if (doubleT > 0f) { Bar(20f, y, "DOUBLE COINS", doubleT / DoubleDur, new Color(1f, 0.65f, 0.2f)); y += 34f; }
            if (dashT > 0f) { Bar(20f, y, "JADE DASH", dashT / DashDur, new Color(0.4f, 1f, 0.45f)); y += 34f; }
            if (shieldT > 0f) { Bar(20f, y, "SHIELD", Mathf.Clamp01(shieldT / ShieldDur), new Color(0.3f, 0.85f, 1f)); y += 34f; }

            // toasts
            float ty = 150f;
            foreach (var t in toasts)
            {
                var c = t.c; c.a = Mathf.Clamp01(t.t * 2f);
                Txt(W * 0.5f - 300f, ty, 600f, 40f, t.s, 28, TextAnchor.MiddleCenter, c);
                ty += 40f;
            }
        }

        void Bar(float x, float y, string name, float frac, Color c)
        {
            Box(x, y, 230f, 26f, new Color(0f, 0f, 0f, 0.45f));
            Box(x + 3f, y + 3f, 224f * Mathf.Clamp01(frac), 20f, new Color(c.r, c.g, c.b, 0.9f));
            Txt(x + 8f, y - 1f, 220f, 28f, name, 17, TextAnchor.MiddleLeft, Color.white);
        }

        void DrawMissions(float x, float y)
        {
            Box(x, y, 400f, 176f, new Color(0f, 0.08f, 0.02f, 0.62f));
            Txt(x + 14f, y + 6f, 360f, 30f, "MISSIONS", 22, TextAnchor.MiddleLeft, new Color(1f, 0.85f, 0.3f));
            for (int i = 0; i < 3; i++)
            {
                var m = Pool[slot[i]];
                int prog = (state == GameState.Menu || state == GameState.Dead) ? 0 : Mathf.Min(m.target, stat[(int)m.kind] - baseline[i]);
                if (state == GameState.Dead) prog = Mathf.Min(m.target, Mathf.Max(0, stat[(int)m.kind] - baseline[i]));
                Txt(x + 14f, y + 40f + i * 44f, 372f, 24f, m.text, 18, TextAnchor.MiddleLeft, Color.white);
                Box(x + 14f, y + 66f + i * 44f, 290f, 10f, new Color(0f, 0f, 0f, 0.5f));
                Box(x + 14f, y + 66f + i * 44f, 290f * (prog / (float)m.target), 10f, new Color(0.5f, 0.95f, 0.4f));
                Txt(x + 310f, y + 56f + i * 44f, 80f, 24f, "+" + m.reward, 18, TextAnchor.MiddleRight, new Color(1f, 0.85f, 0.3f));
            }
        }

        void CloseRunnerPage()
        {
            if (menuPage == 2) Player.SetCharacter(selectedChar); // discard unselected preview
            menuPage = 0;
        }

        void DrawMenu(float W, float H, Color gold)
        {
            if (menuPage == 1) { DrawHowTo(W, H, gold); return; }
            if (menuPage == 2) { DrawRunnerPage(W, H, gold); return; }

            Box(0f, 0f, W, H, new Color(0f, 0.10f, 0.02f, 0.18f));
            Txt(0f, 38f, W, 120f, "BAMBOO RUN", 100, TextAnchor.MiddleCenter, new Color(0.88f, 1f, 0.62f));
            Txt(0f, 148f, W, 40f, "Endless Forest Runner", 30, TextAnchor.MiddleCenter, Color.white);

            GUI.DrawTexture(new Rect(24f, 14f, 36f, 36f), Art.CoinIcon);
            Txt(68f, 10f, 220f, 44f, bank.ToString(), 32, TextAnchor.MiddleLeft, gold);
            Txt(24f, 56f, 400f, 28f, "Best score: " + best + "     Best distance: " + bestDist + " m", 20, TextAnchor.MiddleLeft, Color.white);
            DrawMissions(24f, 300f);

            float bx = W - 380f;
            if (Btn(bx, 280f, 330f, 86f, "PLAY", 46)) StartRun();
            if (Btn(bx, 382f, 330f, 66f, "HOW TO PLAY", 30)) menuPage = 1;
            if (Btn(bx, 464f, 330f, 66f, "CHOOSE RUNNER", 30)) menuPage = 2;
            Txt(bx - 20f, 538f, 370f, 30f, "Runner: " + PlayerController.CharNames[selectedChar], 20, TextAnchor.MiddleCenter, new Color(1f, 1f, 1f, 0.85f));
            Txt(0f, 664f, W, 30f, "Press SPACE to play", 20, TextAnchor.MiddleCenter, new Color(1f, 1f, 1f, 0.7f));
        }

        void DrawHowTo(float W, float H, Color gold)
        {
            Box(0f, 0f, W, H, new Color(0f, 0.06f, 0.02f, 0.45f));
            if (Btn(24f, 24f, 170f, 56f, "< BACK", 26)) CloseRunnerPage();

            // instructions panel
            float px = W * 0.5f - 285f, py = 70f;
            Box(px, py, 570f, 610f, new Color(0f, 0.08f, 0.02f, 0.85f));
            Txt(px, py + 6f, 570f, 56f, "HOW TO PLAY", 40, TextAnchor.MiddleCenter, new Color(0.88f, 1f, 0.62f));
            float y = py + 70f;
            Color white = Color.white;
            Head(px + 24f, ref y, "CONTROLS", gold);
            Line(px + 24f, ref y, "A / D  or  Left / Right  -  change lane", white);
            Line(px + 24f, ref y, "W / Up / Space  -  jump", white);
            Line(px + 24f, ref y, "S / Down  -  slide  (in the air: drop fast)", white);
            Line(px + 24f, ref y, "Touch screen  -  swipe left / right / up / down", white);
            Line(px + 24f, ref y, "P or Esc  -  pause        M  -  mute", white);
            y += 8f;
            Head(px + 24f, ref y, "OBSTACLES", gold);
            Line(px + 24f, ref y, "Shrubs, fallen logs, bamboo fences  -  JUMP", white);
            Line(px + 24f, ref y, "Low beams and tree bridges  -  SLIDE under", white);
            Line(px + 24f, ref y, "Boulders, tree stumps, bamboo clumps  -  CHANGE LANE", white);
            y += 8f;
            Head(px + 24f, ref y, "PICKUPS", gold);
            Line(px + 24f, ref y, "Gold coin = 1 coin      Green jade gem = 10 coins", white);
            Line(px + 24f, ref y, "Red MAGNET  -  pulls coins to you", new Color(1f, 0.5f, 0.45f));
            Line(px + 24f, ref y, "Cyan SHIELD  -  blocks one hit", new Color(0.45f, 0.9f, 1f));
            Line(px + 24f, ref y, "Orange x2  -  double coins", new Color(1f, 0.75f, 0.35f));
            Line(px + 24f, ref y, "Green DASH  -  super fast and unstoppable", new Color(0.5f, 1f, 0.55f));
            y += 8f;
            Head(px + 24f, ref y, "REWARDS", gold);
            Line(px + 24f, ref y, "Bonus coins every 500 m, mission rewards,", white);
            Line(px + 24f, ref y, "and you can spend coins to REVIVE after a crash.", white);

        }

        void DrawRunnerPage(float W, float H, Color gold)
        {
            Box(0f, 0f, W, 110f, new Color(0f, 0.06f, 0.02f, 0.45f));
            Box(0f, 520f, W, 200f, new Color(0f, 0.06f, 0.02f, 0.6f));
            if (Btn(24f, 24f, 170f, 56f, "< BACK", 26)) CloseRunnerPage();
            Txt(0f, 24f, W, 70f, "CHOOSE YOUR RUNNER", 52, TextAnchor.MiddleCenter, new Color(0.88f, 1f, 0.62f));

            float cx = W * 0.5f;
            if (Btn(cx - 330f, 560f, 80f, 70f, "<", 40)) Player.SetCharacter(Player.CharIndex - 1);
            if (Btn(cx + 250f, 560f, 80f, 70f, ">", 40)) Player.SetCharacter(Player.CharIndex + 1);
            Txt(cx - 230f, 536f, 460f, 52f, PlayerController.CharNames[Player.CharIndex], 44, TextAnchor.MiddleCenter, Color.white);
            Txt(cx - 230f, 588f, 460f, 30f, PlayerController.CharDesc[Player.CharIndex], 20, TextAnchor.MiddleCenter, new Color(1f, 1f, 1f, 0.85f));

            bool isSel = Player.CharIndex == selectedChar;
            GUI.enabled = !isSel;
            if (Btn(cx - 140f, 640f, 280f, 60f, isSel ? "SELECTED" : "SELECT", 30))
            {
                selectedChar = Player.CharIndex;
                Save();
                AddToast("Runner selected: " + PlayerController.CharNames[selectedChar], new Color(1f, 0.9f, 0.4f));
            }
            GUI.enabled = true;
            for (int i = 0; i < PlayerController.CharNames.Length; i++)
                Box(cx - 45f + i * 28f, 622f, 16f, 8f, i == Player.CharIndex ? gold : new Color(1f, 1f, 1f, 0.3f));
        }

        void Head(float x, ref float y, string s, Color c) { Txt(x, y, 520f, 30f, s, 22, TextAnchor.MiddleLeft, c); y += 30f; }
        void Line(float x, ref float y, string s, Color c) { Txt(x, y, 540f, 26f, s, 18, TextAnchor.MiddleLeft, c); y += 25f; }

        void DrawPause(float W, float H, Color gold)
        {
            Box(0f, 0f, W, H, new Color(0f, 0.05f, 0.02f, 0.6f));
            Txt(0f, 90f, W, 100f, "PAUSED", 80, TextAnchor.MiddleCenter, Color.white);
            if (Btn(W * 0.5f - 150f, 220f, 300f, 64f, "RESUME", 32)) Resume();
            if (Btn(W * 0.5f - 150f, 300f, 300f, 64f, "RESTART", 32)) { Time.timeScale = 1f; StartRun(); }
            if (Btn(W * 0.5f - 150f, 380f, 300f, 64f, "MAIN MENU", 32)) ReturnToMenu();
            DrawMissions(W * 0.5f - 200f, 480f);
        }

        void DrawGameOver(float W, float H, Color gold)
        {
            Box(0f, 0f, W, H, new Color(0.05f, 0.04f, 0f, 0.55f));
            float px = W * 0.5f - 270f;
            Box(px, 70f, 540f, 600f, new Color(0f, 0.08f, 0.02f, 0.85f));
            Txt(px, 80f, 540f, 80f, "TRIPPED UP!", 56, TextAnchor.MiddleCenter, new Color(1f, 0.55f, 0.35f));
            Txt(px, 160f, 540f, 50f, "Score  " + Score, 42, TextAnchor.MiddleCenter, Color.white);
            if (newBest) Txt(px, 204f, 540f, 34f, "NEW BEST!", 26, TextAnchor.MiddleCenter, gold);
            else Txt(px, 204f, 540f, 34f, "Best  " + best, 22, TextAnchor.MiddleCenter, new Color(0.85f, 1f, 0.85f));
            Txt(px, 242f, 540f, 34f, Mathf.FloorToInt(distance) + " m     coins this run: " + runCoins + "     bank: " + bank, 22, TextAnchor.MiddleCenter, gold);

            if (Btn(px + 120f, 296f, 300f, 64f, "RUN AGAIN", 32)) StartRun();
            int cost = 50 * (revives + 1);
            bool can = revives < 2 && bank >= cost;
            GUI.enabled = can;
            if (Btn(px + 120f, 372f, 300f, 64f, revives >= 2 ? "NO REVIVES LEFT" : "REVIVE  (-" + cost + " coins)", 26)) Revive();
            GUI.enabled = true;
            if (Btn(px + 120f, 448f, 300f, 64f, "MAIN MENU", 32)) ReturnToMenu();
            Txt(px, 530f, 540f, 30f, "Space / R = run again", 18, TextAnchor.MiddleCenter, new Color(1f, 1f, 1f, 0.7f));
        }
    }
}
