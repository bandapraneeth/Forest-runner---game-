using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using Random = UnityEngine.Random;

namespace BambooRunner
{
    /// <summary>
    /// Endless forest built from recycled 48 m chunks. Chunks scroll toward the player;
    /// every chunk holds swaying bamboo, ferns, rocks, light shafts, obstacles and pickups.
    /// </summary>
    public class WorldGenerator : MonoBehaviour
    {
        public const float ChunkLen = 48f;
        public const float LaneW = 2.3f;
        const int ChunkCount = 6;
        const float RowA = 16f, RowB = 38f;

        public enum ColType { Coin, Gem, Magnet, Shield, Double, Dash }

        class Obstacle { public Transform t; public float hx, hz, y0, y1; public bool dead; }
        class Collectible { public Transform t, spin, halo; public ColType type; public bool taken; public float baseY, phase; }
        class Chunk
        {
            public Transform root, content;
            public Transform[] stalks; public MeshFilter[] stalkMF; public MeshRenderer[] stalkMR;
            public float[] sYaw, sPhase, sAmp;
            public Transform[] ferns, rocks, shafts;
            public MeshFilter[] fernMF;
            public List<Obstacle> obs = new List<Obstacle>();
            public List<Collectible> cols = new List<Collectible>();
        }

        Chunk[] chunks;
        public bool safe = true;
        float time, distRef;
        Camera cam;
        ParticleSystem fx, leaves;
        Mesh cyl, cube, sph, quad;

        // ------------------------------------------------------------------ setup
        public void Init(Camera c)
        {
            cam = c;
            cyl = Art.Prim(PrimitiveType.Cylinder);
            cube = Art.Prim(PrimitiveType.Cube);
            sph = Art.Prim(PrimitiveType.Sphere);
            quad = Art.Prim(PrimitiveType.Quad);

            var rootGO = new GameObject("World");
            rootGO.transform.SetParent(transform, false);
            chunks = new Chunk[ChunkCount];
            for (int i = 0; i < ChunkCount; i++) chunks[i] = BuildChunk(i, rootGO.transform);
            BuildFx();
            ResetWorld(true);
        }

        Chunk BuildChunk(int index, Transform parent)
        {
            var c = new Chunk();
            var rg = new GameObject("Chunk" + index);
            rg.transform.SetParent(parent, false);
            c.root = rg.transform;

            // ground
            var ground = Art.Part("Ground", quad, Art.groundMat, c.root, new Vector3(0f, 0f, ChunkLen * 0.5f),
                new Vector3(60f, ChunkLen + 0.2f, 1f), new Vector3(90f, 0f, 0f));
            ground.GetComponent<MeshRenderer>().shadowCastingMode = ShadowCastingMode.Off;

            c.content = new GameObject("Content").transform;
            c.content.SetParent(c.root, false);

            int perSide = Art.Quality == 0 ? 20 : 40;
            int n = perSide * 2;
            c.stalks = new Transform[n]; c.stalkMF = new MeshFilter[n]; c.stalkMR = new MeshRenderer[n];
            c.sYaw = new float[n]; c.sPhase = new float[n]; c.sAmp = new float[n];
            for (int i = 0; i < n; i++)
            {
                var go = new GameObject("Bamboo");
                go.transform.SetParent(c.root, false);
                c.stalks[i] = go.transform;
                c.stalkMF[i] = go.AddComponent<MeshFilter>();
                var mr = go.AddComponent<MeshRenderer>();
                mr.shadowCastingMode = ShadowCastingMode.Off;
                mr.receiveShadows = false;
                c.stalkMR[i] = mr;
            }

            int nf = Art.Quality == 0 ? 8 : 16;
            c.ferns = new Transform[nf]; c.fernMF = new MeshFilter[nf];
            for (int i = 0; i < nf; i++)
            {
                var go = new GameObject("Fern");
                go.transform.SetParent(c.root, false);
                c.ferns[i] = go.transform;
                c.fernMF[i] = go.AddComponent<MeshFilter>();
                var mr = go.AddComponent<MeshRenderer>();
                mr.sharedMaterial = Art.LeafMats[i % 2];
                mr.shadowCastingMode = ShadowCastingMode.Off;
            }

            c.rocks = new Transform[6];
            for (int i = 0; i < c.rocks.Length; i++)
                c.rocks[i] = Art.Part("Rock", sph, i % 2 == 0 ? Art.rockMat : Art.mossMat, c.root, Vector3.zero, Vector3.one).transform;

            c.shafts = new Transform[3];
            for (int i = 0; i < c.shafts.Length; i++)
                c.shafts[i] = Art.Part("Shaft", quad, Art.shaftMat, c.root, Vector3.zero, Vector3.one, default(Vector3), false).transform;

            return c;
        }

        void BuildFx()
        {
            // pickup / smash sparkles
            var go = new GameObject("FX");
            go.transform.SetParent(transform, false);
            fx = go.AddComponent<ParticleSystem>();
            var main = fx.main;
            main.loop = true; main.playOnAwake = false;
            main.startLifetime = 0.7f; main.startSpeed = 0f; main.startSize = 0.28f;
            main.gravityModifier = 0.5f;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.maxParticles = 800;
            var em = fx.emission; em.enabled = false;
            var sh = fx.shape; sh.enabled = false;
            var col = fx.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new GradientColorKey[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                      new GradientAlphaKey[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0f, 1f) });
            col.color = g;
            var sz = fx.sizeOverLifetime; sz.enabled = true;
            sz.size = new ParticleSystem.MinMaxCurve(1f, AnimationCurve.Linear(0f, 1f, 1f, 0.2f));
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = Art.fxMat;
            r.renderMode = ParticleSystemRenderMode.Billboard;
            fx.Play();

            // drifting leaves
            var lg = new GameObject("FallingLeaves");
            lg.transform.SetParent(transform, false);
            lg.transform.position = new Vector3(0f, 13f, 45f);
            leaves = lg.AddComponent<ParticleSystem>();
            var lm = leaves.main;
            lm.loop = true; lm.playOnAwake = true; lm.prewarm = true;
            lm.startLifetime = 6f; lm.startSpeed = 0f;
            lm.startSize = new ParticleSystem.MinMaxCurve(0.18f, 0.34f);
            lm.startRotation = new ParticleSystem.MinMaxCurve(0f, 6.28f);
            lm.startColor = new ParticleSystem.MinMaxGradient(new Color(0.45f, 0.72f, 0.22f), new Color(0.95f, 0.84f, 0.30f));
            lm.gravityModifier = 0.03f;
            lm.simulationSpace = ParticleSystemSimulationSpace.World;
            lm.maxParticles = 160;
            var le = leaves.emission; le.rateOverTime = Art.Quality == 0 ? 8f : 16f;
            var ls = leaves.shape; ls.shapeType = ParticleSystemShapeType.Box; ls.scale = new Vector3(34f, 1f, 110f);
            var lv = leaves.velocityOverLifetime; lv.enabled = true; lv.space = ParticleSystemSimulationSpace.World;
            lv.x = new ParticleSystem.MinMaxCurve(0f); lv.y = new ParticleSystem.MinMaxCurve(0f); lv.z = new ParticleSystem.MinMaxCurve(-6f);
            var ln = leaves.noise; ln.enabled = true; ln.strength = 1.3f; ln.frequency = 0.25f;
            var lr = leaves.rotationOverLifetime; lr.enabled = true; lr.z = new ParticleSystem.MinMaxCurve(-2.5f, 2.5f);
            var lrr = lg.GetComponent<ParticleSystemRenderer>();
            lrr.sharedMaterial = Art.leafPartMat;
            lrr.renderMode = ParticleSystemRenderMode.Billboard;
            leaves.Play();
        }

        public void Burst(Vector3 pos, Color color, int count)
        {
            if (fx == null) return;
            var ep = new ParticleSystem.EmitParams();
            for (int i = 0; i < count; i++)
            {
                ep.position = pos;
                ep.velocity = Random.insideUnitSphere * 4.5f + Vector3.up * 1.5f;
                ep.startColor = color;
                ep.startSize = Random.Range(0.18f, 0.38f);
                ep.startLifetime = Random.Range(0.4f, 0.8f);
                fx.Emit(ep, 1);
            }
        }

        // ------------------------------------------------------------------ world control
        public void ResetWorld(bool menuMode)
        {
            safe = menuMode;
            for (int i = 0; i < ChunkCount; i++)
            {
                var c = chunks[i];
                c.root.position = new Vector3(0f, 0f, (i - 1) * ChunkLen);
                Scatter(c);
                // the first chunks ahead of the player are always obstacle-free
                Populate(c, menuMode || i <= 1, (i - 1) * ChunkLen);
            }
        }

        public void ClearAhead(float zMax)
        {
            foreach (var c in chunks)
                foreach (var o in c.obs)
                {
                    if (o.dead) continue;
                    float z = o.t.position.z;
                    if (z > -3f && z < zMax) Smash(o);
                }
        }

        float MaxZ()
        {
            float m = float.MinValue;
            foreach (var c in chunks) if (c.root.position.z > m) m = c.root.position.z;
            return m;
        }

        public void Tick(float dt, float speed, float distance)
        {
            time += dt;
            distRef = distance;
            float dz = speed * dt;

            foreach (var c in chunks)
            {
                var p = c.root.position; p.z -= dz; c.root.position = p;
            }
            foreach (var c in chunks)
            {
                if (c.root.position.z < -ChunkLen - 14f)
                {
                    float nz = MaxZ() + ChunkLen;
                    c.root.position = new Vector3(0f, 0f, nz);
                    Scatter(c);
                    Populate(c, safe, distance + nz);
                }
            }

            // sway, spin, bob
            Quaternion camRot = cam != null ? cam.transform.rotation : Quaternion.identity;
            foreach (var c in chunks)
            {
                float cz = c.root.position.z;
                if (cz > 260f) continue;
                for (int i = 0; i < c.stalks.Length; i++)
                {
                    float s = time * 0.8f + c.sPhase[i];
                    c.stalks[i].localRotation = Quaternion.Euler(Mathf.Sin(s) * c.sAmp[i], c.sYaw[i], Mathf.Cos(s * 0.8f) * c.sAmp[i]);
                }
                for (int i = 0; i < c.cols.Count; i++)
                {
                    var col = c.cols[i];
                    if (col.taken || col.t == null) continue;
                    col.spin.Rotate(0f, 200f * dt, 0f, Space.Self);
                    if (col.halo != null)
                    {
                        col.halo.rotation = camRot;
                        var lp = col.t.localPosition;
                        lp.y = col.baseY + Mathf.Sin(time * 3f + col.phase) * 0.12f;
                        col.t.localPosition = lp;
                    }
                }
            }

            if (leaves != null)
            {
                var v = leaves.velocityOverLifetime;
                v.z = new ParticleSystem.MinMaxCurve(-speed);
            }
        }

        // ------------------------------------------------------------------ collisions
        void Smash(Obstacle o)
        {
            o.dead = true;
            if (o.t != null)
            {
                Burst(o.t.position + Vector3.up, new Color(0.9f, 0.8f, 0.45f), 18);
                o.t.gameObject.SetActive(false);
            }
        }

        public bool CheckHit(float px, float py, float h, float sweep, bool consume)
        {
            bool hit = false;
            foreach (var c in chunks)
            {
                float cz = c.root.position.z;
                if (cz > 8f || cz + ChunkLen < -6f) continue;
                for (int i = 0; i < c.obs.Count; i++)
                {
                    var o = c.obs[i];
                    if (o.dead) continue;
                    Vector3 p = o.t.position;
                    if (Mathf.Abs(p.x - px) < o.hx + 0.34f && Mathf.Abs(p.z) < o.hz + 0.30f + sweep * 0.5f
                        && py + 0.04f < o.y1 && py + h > o.y0)
                    {
                        hit = true;
                        if (consume) Smash(o); else return true;
                    }
                }
            }
            return hit;
        }

        public void Collect(float px, float py, float h, float sweep, bool magnet, float dt, System.Action<ColType, Vector3> cb)
        {
            Vector3 chest = new Vector3(px, py + Mathf.Min(h * 0.55f, 1f), 0f);
            foreach (var c in chunks)
            {
                float cz = c.root.position.z;
                if (cz > 30f || cz + ChunkLen < -6f) continue;
                for (int i = 0; i < c.cols.Count; i++)
                {
                    var col = c.cols[i];
                    if (col.taken || col.t == null) continue;
                    Vector3 p = col.t.position;
                    if (magnet && (col.type == ColType.Coin || col.type == ColType.Gem) && p.z > -2f && (p - chest).sqrMagnitude < 64f)
                    {
                        p = Vector3.MoveTowards(p, chest, 30f * dt);
                        col.t.position = p;
                    }
                    if (Mathf.Abs(p.x - px) < 0.75f && Mathf.Abs(p.z) < 0.6f + sweep * 0.5f && p.y > py - 0.25f && p.y < py + h + 0.25f)
                    {
                        col.taken = true;
                        col.t.gameObject.SetActive(false);
                        if (cb != null) cb(col.type, p);
                    }
                }
            }
        }

        // ------------------------------------------------------------------ scenery scatter
        void Scatter(Chunk c)
        {
            int n = c.stalks.Length;
            int perSide = n / 2;
            int nearN = Art.Quality == 0 ? 6 : 12;
            for (int side = -1; side <= 1; side += 2)
            {
                float cx = 0f, cz = 0f;
                for (int i = 0; i < perSide; i++)
                {
                    int idx = (side < 0 ? 0 : perSide) + i;
                    bool near = i < nearN;
                    if (i % 3 == 0)
                    {
                        cx = near ? Random.Range(4.9f, 8.5f) : Random.Range(8.5f, 26f);
                        cz = Random.Range(0f, ChunkLen);
                    }
                    float x = (cx + Random.Range(-0.5f, 0.5f)) * side;
                    float z = cz + Random.Range(-0.5f, 0.5f);
                    var t = c.stalks[idx];
                    t.localPosition = new Vector3(x, -0.15f, z);
                    float s = Random.Range(0.85f, 1.3f);
                    t.localScale = new Vector3(s, Random.Range(0.9f, 1.2f), s);
                    float yaw = (x > 0f ? 180f : 0f) + Random.Range(-50f, 50f);
                    c.sYaw[idx] = yaw;
                    c.sPhase[idx] = Random.Range(0f, 6.28f);
                    c.sAmp[idx] = Random.Range(0.4f, 1.1f);
                    c.stalkMF[idx].sharedMesh = near ? Art.NearStalks[Random.Range(0, Art.NearStalks.Length)]
                                                     : Art.FarStalks[Random.Range(0, Art.FarStalks.Length)];
                    c.stalkMR[idx].sharedMaterials = Art.StalkCombos[Random.Range(0, Art.StalkCombos.Length)];
                    t.localRotation = Quaternion.Euler(0f, yaw, 0f);
                }
            }
            for (int i = 0; i < c.ferns.Length; i++)
            {
                int side = Random.value < 0.5f ? -1 : 1;
                c.ferns[i].localPosition = new Vector3(side * Random.Range(3.9f, 14f), 0f, Random.Range(0f, ChunkLen));
                c.ferns[i].localRotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
                c.ferns[i].localScale = Vector3.one * Random.Range(0.7f, 1.5f);
                c.fernMF[i].sharedMesh = Art.Ferns[Random.Range(0, Art.Ferns.Length)];
            }
            for (int i = 0; i < c.rocks.Length; i++)
            {
                int side = Random.value < 0.5f ? -1 : 1;
                float sy = Random.Range(0.3f, 0.9f);
                c.rocks[i].localScale = new Vector3(Random.Range(0.6f, 1.6f), sy, Random.Range(0.6f, 1.3f));
                c.rocks[i].localPosition = new Vector3(side * Random.Range(4.2f, 12f), sy * 0.2f, Random.Range(0f, ChunkLen));
                c.rocks[i].localRotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
            }
            for (int i = 0; i < c.shafts.Length; i++)
            {
                float sx = (Random.value < 0.5f ? -1f : 1f) * Random.Range(1.5f, 12f);
                c.shafts[i].localPosition = new Vector3(sx, 7.5f, Random.Range(2f, ChunkLen - 2f));
                c.shafts[i].localScale = new Vector3(Random.Range(2.5f, 4.5f), Random.Range(13f, 17f), 1f);
                c.shafts[i].localRotation = Quaternion.Euler(0f, Random.Range(-20f, 20f), Random.Range(10f, 24f) * (Random.value < 0.5f ? -1f : 1f));
            }
        }

        // ------------------------------------------------------------------ gameplay content
        void ClearContent(Chunk c)
        {
            for (int i = c.content.childCount - 1; i >= 0; i--)
            {
                var g = c.content.GetChild(i).gameObject;
                g.SetActive(false);
                Destroy(g);
            }
            c.obs.Clear();
            c.cols.Clear();
        }

        void Populate(Chunk c, bool noObstacles, float startDist)
        {
            ClearContent(c);
            float d = Mathf.Clamp01(startDist / 3500f);

            if (noObstacles)
            {
                if (!safe) CoinLine(c, 0f, 8f, ChunkLen - 4f, 12);   // menu = clean empty path
                return;
            }

            int[] lanesA = new int[3], lanesB = new int[3];
            SpawnRow(c, RowA, d, lanesA);
            CoinsForRow(c, RowA, lanesA, 9f);
            SpawnRow(c, RowB, d, lanesB);
            CoinsForRow(c, RowB, lanesB, 7f);

            // power-up between the rows
            if (Random.value < 0.42f)
            {
                float r = Random.value;
                ColType t = r < 0.30f ? ColType.Magnet : r < 0.55f ? ColType.Shield : r < 0.80f ? ColType.Double : ColType.Dash;
                int lane = Random.Range(-1, 2);
                AddCol(c, t, lane * LaneW, 1.1f, 28f);
            }
            if (Random.value < 0.45f) Lanterns(c, Random.Range(6f, ChunkLen - 6f));
        }

        void SpawnRow(Chunk c, float z, float d, int[] lanes)
        {
            lanes[0] = lanes[1] = lanes[2] = 0;
            float p = Random.value;
            if (p < 0.10f - 0.06f * d) return;

            p = Random.value;
            if (p < 0.38f)
            {
                int l = Random.Range(0, 3);
                lanes[l] = Random.Range(1, 4);
            }
            else if (p < 0.58f)
            {
                int free = Random.Range(0, 3);
                for (int l = 0; l < 3; l++) if (l != free) lanes[l] = Random.Range(1, 4);
            }
            else if (p < 0.70f)
            {
                lanes[0] = lanes[1] = lanes[2] = 1;
                c.obs.Add(MakeLow(c, 0f, z, 6.9f));
                return;
            }
            else if (p < 0.82f)
            {
                lanes[0] = lanes[1] = lanes[2] = 2;
                c.obs.Add(MakeHigh(c, 0f, z, 6.9f));
                return;
            }
            else if (d > 0.15f)
            {
                // low / high / block in random order: read the lanes!
                int[] k = { 1, 2, 3 };
                for (int i = 2; i > 0; i--) { int j = Random.Range(0, i + 1); int tmp = k[i]; k[i] = k[j]; k[j] = tmp; }
                for (int l = 0; l < 3; l++) lanes[l] = k[l];
            }
            else
            {
                lanes[Random.Range(0, 3)] = Random.Range(1, 4);
            }

            for (int l = 0; l < 3; l++)
            {
                float x = (l - 1) * LaneW;
                if (lanes[l] == 1) c.obs.Add(MakeLow(c, x, z, 2.0f));
                else if (lanes[l] == 2) c.obs.Add(MakeHigh(c, x, z, 2.1f));
                else if (lanes[l] == 3) c.obs.Add(MakeBlock(c, x, z));
            }
        }

        void CoinsForRow(Chunk c, float z, int[] lanes, float lineLen)
        {
            // arcs of coins over low obstacles reward the jump
            for (int l = 0; l < 3; l++)
                if (lanes[l] == 1 && Random.value < 0.75f)
                    CoinArc(c, (l - 1) * LaneW, z, 5);

            // a line of coins in a free lane after the row
            var free = new List<int>();
            for (int l = 0; l < 3; l++) if (lanes[l] == 0) free.Add(l);
            if (free.Count > 0 && Random.value < 0.8f)
            {
                int l = free[Random.Range(0, free.Count)];
                float z0 = z + 4f;
                float z1 = Mathf.Min(z + 4f + lineLen, ChunkLen - 0.5f);
                CoinLine(c, (l - 1) * LaneW, z0, z1, Mathf.Max(3, Mathf.RoundToInt((z1 - z0) / 1.7f)));
            }
        }

        void CoinLine(Chunk c, float x, float z0, float z1, int count)
        {
            for (int i = 0; i < count; i++)
            {
                float z = count == 1 ? z0 : Mathf.Lerp(z0, z1, (float)i / (count - 1));
                ColType t = Random.value < 0.045f ? ColType.Gem : ColType.Coin;
                AddCol(c, t, x, 1.0f, z);
            }
        }

        void CoinArc(Chunk c, float x, float zc, int count)
        {
            for (int i = 0; i < count; i++)
            {
                float u = count == 1 ? 0f : (i / (float)(count - 1)) * 2f - 1f;
                float y = 0.95f + 1.05f * (1f - u * u);
                AddCol(c, ColType.Coin, x, y, zc + u * 3.2f);
            }
        }

        // ------------------------------------------------------------------ builders
        Transform NewRoot(Chunk c, string name, float x, float z)
        {
            var t = new GameObject(name).transform;
            t.SetParent(c.content, false);
            t.localPosition = new Vector3(x, 0f, z);
            return t;
        }

        Obstacle MakeFence(Chunk c, float x, float z, float w)
        {
            var root = NewRoot(c, "LowBarrier", x, z);
            float half = w * 0.5f;
            for (int s = -1; s <= 1; s += 2)
                Art.Part("Post", cyl, Art.cutBamboo, root, new Vector3(s * (half - 0.18f), 0.5f, 0f), new Vector3(0.24f, 0.5f, 0.24f));
            Art.Part("Rail", cyl, Art.cutBamboo, root, new Vector3(0f, 0.17f, 0f), new Vector3(0.28f, half, 0.28f), new Vector3(0f, 0f, 90f));
            Art.Part("Rail", cyl, Art.cutBamboo, root, new Vector3(0f, 0.42f, 0.02f), new Vector3(0.26f, half, 0.26f), new Vector3(0f, 0f, 90f));
            Art.Part("Rail", cyl, Art.cutBamboo, root, new Vector3(0f, 0.66f, 0f), new Vector3(0.26f, half, 0.26f), new Vector3(0f, 0f, 90f));
            for (int s = -1; s <= 1; s += 2)
                Art.Part("Rope", cyl, Art.ropeMat, root, new Vector3(s * (half - 0.18f), 0.42f, 0f), new Vector3(0.30f, 0.05f, 0.30f));
            return new Obstacle { t = root, hx = half - 0.05f, hz = 0.28f, y0 = 0f, y1 = 0.80f };
        }

        Obstacle MakeBeam(Chunk c, float x, float z, float w)
        {
            var root = NewRoot(c, "HighBarrier", x, z);
            float half = w * 0.5f;
            for (int s = -1; s <= 1; s += 2)
                Art.Part("Post", cyl, Art.cutBamboo, root, new Vector3(s * (half - 0.12f), 1.5f, 0f), new Vector3(0.30f, 1.5f, 0.30f));
            Art.Part("Beam", cyl, Art.cutBamboo, root, new Vector3(0f, 1.45f, 0f), new Vector3(0.40f, half, 0.40f), new Vector3(0f, 0f, 90f));
            Art.Part("Beam", cyl, Art.cutBamboo, root, new Vector3(0f, 1.95f, 0f), new Vector3(0.30f, half, 0.30f), new Vector3(0f, 0f, 90f));
            Art.Part("Banner", cube, Art.bannerMat, root, new Vector3(0f, 1.08f, 0f), new Vector3(0.55f, 0.34f, 0.04f));
            for (int s = -1; s <= 1; s += 2)
                Art.Part("Rope", cyl, Art.ropeMat, root, new Vector3(s * (half - 0.12f), 1.45f, 0f), new Vector3(0.34f, 0.05f, 0.34f));
            return new Obstacle { t = root, hx = half - 0.05f, hz = 0.30f, y0 = 1.22f, y1 = 2.2f };
        }


        // ---- variant pickers: forest themed obstacles ----
        Obstacle MakeLow(Chunk c, float x, float z, float w)
        {
            float r = Random.value;
            if (w > 3f) return r < 0.5f ? MakeFence(c, x, z, w) : MakeLog(c, x, z, w);
            if (r < 0.30f) return MakeFence(c, x, z, w);
            if (r < 0.65f) return MakeShrub(c, x, z);
            return MakeLog(c, x, z, w);
        }

        Obstacle MakeHigh(Chunk c, float x, float z, float w)
        {
            return Random.value < 0.5f ? MakeBeam(c, x, z, w) : MakeTreeBridge(c, x, z, w);
        }

        void Mushrooms(Transform parent, float x, float y, float z)
        {
            Art.Part("Stem", cyl, Art.trouserMat, parent, new Vector3(x, y + 0.07f, z), new Vector3(0.07f, 0.08f, 0.07f), default(Vector3), false);
            Art.Part("Cap", sph, Art.mushCapMat, parent, new Vector3(x, y + 0.17f, z), new Vector3(0.22f, 0.12f, 0.22f), default(Vector3), false);
        }

        // small leafy shrub with flowers: jump over it
        Obstacle MakeShrub(Chunk c, float x, float z)
        {
            var root = NewRoot(c, "Shrub", x, z);
            Art.Part("B1", sph, Art.shrubMat, root, new Vector3(0f, 0.38f, 0f), new Vector3(1.5f, 0.85f, 1.2f));
            Art.Part("B2", sph, Art.shrubMat2, root, new Vector3(-0.55f, 0.30f, 0.1f), new Vector3(0.95f, 0.65f, 0.9f));
            Art.Part("B3", sph, Art.shrubMat2, root, new Vector3(0.55f, 0.32f, -0.1f), new Vector3(1.0f, 0.7f, 0.9f));
            Art.Part("B4", sph, Art.shrubMat, root, new Vector3(0.1f, 0.55f, 0.15f), new Vector3(0.9f, 0.6f, 0.8f));
            for (int i = 0; i < 6; i++)
                Art.Part("Flower", sph, Art.flowerMat, root, new Vector3(Random.Range(-0.7f, 0.7f), Random.Range(0.45f, 0.75f), Random.Range(-0.5f, 0.5f)),
                    Vector3.one * 0.11f, default(Vector3), false);
            Art.Part("Fern", Art.Ferns[Random.Range(0, Art.Ferns.Length)], Art.LeafMats[0], root, new Vector3(0f, 0.2f, 0f),
                Vector3.one * 1.1f, new Vector3(0f, Random.Range(0f, 360f), 0f), false);
            return new Obstacle { t = root, hx = 0.8f, hz = 0.55f, y0 = 0f, y1 = 0.8f };
        }

        // fallen tree trunk lying across the path: jump over it
        Obstacle MakeLog(Chunk c, float x, float z, float w)
        {
            var root = NewRoot(c, "FallenTree", x, z);
            float len = w > 3f ? w : 2.2f;
            float half = len * 0.5f;
            float dia = 0.72f;
            Art.Part("Trunk", cyl, Art.barkMat, root, new Vector3(0f, dia * 0.5f + 0.02f, 0f), new Vector3(dia, half, dia), new Vector3(0f, 0f, 90f));
            Art.Part("Cut", cyl, Art.stumpTopMat, root, new Vector3(half, dia * 0.5f + 0.02f, 0f), new Vector3(dia * 0.9f, 0.02f, dia * 0.9f), new Vector3(0f, 0f, 90f));
            Art.Part("Branch", cyl, Art.barkMat, root, new Vector3(-half * 0.5f, 0.78f, 0.15f), new Vector3(0.12f, 0.28f, 0.12f), new Vector3(35f, 0f, 20f));
            Art.Part("Branch", cyl, Art.barkMat, root, new Vector3(half * 0.3f, 0.82f, -0.1f), new Vector3(0.10f, 0.25f, 0.10f), new Vector3(-30f, 0f, -25f));
            Art.Part("Moss", sph, Art.mossMat, root, new Vector3(-half * 0.2f, dia + 0.02f, 0f), new Vector3(0.9f, 0.18f, 0.5f));
            Mushrooms(root, 0.4f, dia + 0.02f, 0.1f);
            Mushrooms(root, 0.55f, dia + 0.0f, -0.12f);
            return new Obstacle { t = root, hx = half - 0.05f, hz = 0.38f, y0 = 0f, y1 = 0.82f };
        }

        // fallen tree propped on forked stumps: slide under it
        Obstacle MakeTreeBridge(Chunk c, float x, float z, float w)
        {
            var root = NewRoot(c, "TreeBridge", x, z);
            float half = w * 0.5f;
            for (int s = -1; s <= 1; s += 2)
            {
                float px = s * (half - 0.15f);
                Art.Part("Stump", cyl, Art.barkMat, root, new Vector3(px, 0.9f, 0f), new Vector3(0.55f, 0.9f, 0.55f));
                Art.Part("Roots", sph, Art.barkMat, root, new Vector3(px, 0.12f, 0f), new Vector3(0.95f, 0.28f, 0.95f));
            }
            Art.Part("Trunk", cyl, Art.barkMat, root, new Vector3(0f, 1.75f, 0f), new Vector3(0.52f, half + 0.3f, 0.52f), new Vector3(0f, 0f, 90f));
            Art.Part("Moss", sph, Art.mossMat, root, new Vector3(-half * 0.3f, 2.05f, 0f), new Vector3(1.1f, 0.2f, 0.6f));
            Art.Part("Branch", cyl, Art.barkMat, root, new Vector3(half * 0.4f, 2.25f, 0.1f), new Vector3(0.12f, 0.35f, 0.12f), new Vector3(20f, 0f, -35f));
            return new Obstacle { t = root, hx = half - 0.05f, hz = 0.35f, y0 = 1.32f, y1 = 2.25f };
        }

        // big cut stump: change lane
        Obstacle MakeStump(Chunk c, float x, float z)
        {
            var root = NewRoot(c, "Stump", x, z);
            Art.Part("Trunk", cyl, Art.barkMat, root, new Vector3(0f, 1.0f, 0f), new Vector3(1.7f, 1.0f, 1.7f));
            Art.Part("Top", cyl, Art.stumpTopMat, root, new Vector3(0f, 2.0f, 0f), new Vector3(1.55f, 0.03f, 1.55f));
            Art.Part("Ring", cyl, Art.barkMat, root, new Vector3(0f, 2.04f, 0f), new Vector3(0.7f, 0.02f, 0.7f));
            for (int i = 0; i < 4; i++)
            {
                float a = i * 90f + 20f;
                Art.Part("Root", cube, Art.barkMat, root, Quaternion.Euler(0f, a, 0f) * new Vector3(0f, 0.2f, 0.95f),
                    new Vector3(0.35f, 0.3f, 0.9f), new Vector3(20f, a, 0f));
            }
            Art.Part("Moss", sph, Art.mossMat, root, new Vector3(0.5f, 1.2f, 0.7f), new Vector3(0.7f, 0.5f, 0.3f));
            Mushrooms(root, 0.4f, 0.0f, 1.1f);
            return new Obstacle { t = root, hx = 0.85f, hz = 0.85f, y0 = 0f, y1 = 2.05f };
        }

        Obstacle MakeBlock(Chunk c, float x, float z)
        {
            float r = Random.value;
            if (r < 0.30f) return MakeStump(c, x, z);
            if (r < 0.60f) return MakeBoulder(c, x, z);
            return MakeBambooClump(c, x, z);
        }

        // mossy boulder overgrown with ferns
        Obstacle MakeBoulder(Chunk c, float x, float z)
        {
            var root = NewRoot(c, "Boulder", x, z);
            float yaw = Random.Range(0f, 360f);
            Art.Part("Rock", sph, Art.rockMat, root, new Vector3(0f, 0.95f, 0f), new Vector3(1.7f, 1.9f, 1.5f), new Vector3(0f, yaw, 0f));
            Art.Part("Rock2", sph, Art.rockMat, root, new Vector3(0.6f, 0.45f, 0.3f), new Vector3(1.0f, 0.95f, 1.0f));
            Art.Part("Moss", sph, Art.mossMat, root, new Vector3(0f, 1.7f, 0f), new Vector3(1.4f, 0.55f, 1.2f), new Vector3(0f, yaw, 0f));
            Art.Part("Moss2", sph, Art.mossMat, root, new Vector3(-0.5f, 0.9f, 0.5f), new Vector3(0.7f, 0.6f, 0.45f));
            Art.Part("Fern", Art.Ferns[Random.Range(0, Art.Ferns.Length)], Art.LeafMats[0], root, new Vector3(0.8f, 0.05f, 0.6f), Vector3.one * 1.0f, default(Vector3), false);
            Art.Part("Fern", Art.Ferns[Random.Range(0, Art.Ferns.Length)], Art.LeafMats[1], root, new Vector3(-0.8f, 0.05f, -0.5f), Vector3.one * 0.9f, default(Vector3), false);
            return new Obstacle { t = root, hx = 0.78f, hz = 0.75f, y0 = 0f, y1 = 2.0f };
        }

        // dense clump of thick bamboo growing on the path: change lane
        Obstacle MakeBambooClump(Chunk c, float x, float z)
        {
            var root = NewRoot(c, "BambooClump", x, z);
            Material green = Art.StalkCombos[0][0];
            for (int i = 0; i < 7; i++)
            {
                float a = i * 51f + Random.Range(0f, 20f);
                float rad = i == 0 ? 0f : Random.Range(0.35f, 0.65f);
                Vector3 p = Quaternion.Euler(0f, a, 0f) * new Vector3(0f, 0f, rad);
                float d = Random.Range(0.26f, 0.34f);
                int segs = 3 + (i % 2);
                for (int sIdx = 0; sIdx < segs; sIdx++)
                    Art.Part("Seg", cyl, green, root, new Vector3(p.x, 0.5f + sIdx * 1.0f, p.z), new Vector3(d, 0.5f, d), default(Vector3), true);
            }
            Art.Part("Leaves", sph, Art.shrubMat, root, new Vector3(0f, 2.9f, 0f), new Vector3(1.6f, 0.7f, 1.6f));
            Art.Part("Leaves2", sph, Art.shrubMat2, root, new Vector3(0.3f, 3.2f, -0.2f), new Vector3(1.1f, 0.5f, 1.1f));
            Art.Part("Fern", Art.Ferns[Random.Range(0, Art.Ferns.Length)], Art.LeafMats[0], root, new Vector3(0f, 0.05f, 0f), Vector3.one * 1.2f, default(Vector3), false);
            return new Obstacle { t = root, hx = 0.8f, hz = 0.7f, y0 = 0f, y1 = 3.0f };
        }

        void Lanterns(Chunk c, float z)
        {
            float w = 14f;
            Art.Part("Rope", cyl, Art.ropeMat, c.content, new Vector3(0f, 5.4f, z), new Vector3(0.04f, w * 0.5f, 0.04f), new Vector3(0f, 0f, 90f), false);
            for (int i = 0; i < 5; i++)
            {
                float lx = -5.6f + i * 2.8f;
                float sag = 0.25f * (1f - Mathf.Abs(lx) / 5.6f);
                Art.Part("String", cyl, Art.ropeMat, c.content, new Vector3(lx, 5.1f - sag, z), new Vector3(0.02f, 0.25f, 0.02f), default(Vector3), false);
                Art.Part("Lantern", sph, Art.lanternMat, c.content, new Vector3(lx, 4.7f - sag, z), new Vector3(0.45f, 0.58f, 0.45f), default(Vector3), false);
            }
        }

        Collectible AddCol(Chunk c, ColType type, float x, float y, float z)
        {
            var root = new GameObject(type.ToString()).transform;
            root.SetParent(c.content, false);
            root.localPosition = new Vector3(x, y, z);
            var spin = new GameObject("Spin").transform;
            spin.SetParent(root, false);
            Transform halo = null;
            Material haloMat = null;

            switch (type)
            {
                case ColType.Coin:
                    Art.Part("Disc", cyl, Art.goldMat, spin, Vector3.zero, new Vector3(0.62f, 0.05f, 0.62f), new Vector3(90f, 0f, 0f), false);
                    Art.Part("Hole", cube, Art.goldDarkMat, spin, Vector3.zero, new Vector3(0.20f, 0.20f, 0.09f), default(Vector3), false);
                    break;
                case ColType.Gem:
                    Art.Part("Jade", cube, Art.jadeMat, spin, Vector3.zero, Vector3.one * 0.44f, new Vector3(45f, 45f, 0f), false);
                    break;
                case ColType.Magnet:
                    Art.Part("L", cube, Art.magnetMat, spin, new Vector3(-0.2f, -0.02f, 0f), new Vector3(0.16f, 0.52f, 0.16f), default(Vector3), false);
                    Art.Part("R", cube, Art.magnetMat, spin, new Vector3(0.2f, -0.02f, 0f), new Vector3(0.16f, 0.52f, 0.16f), default(Vector3), false);
                    Art.Part("B", cube, Art.magnetMat, spin, new Vector3(0f, -0.2f, 0f), new Vector3(0.56f, 0.16f, 0.16f), default(Vector3), false);
                    Art.Part("TL", cube, Art.silverMat, spin, new Vector3(-0.2f, 0.3f, 0f), new Vector3(0.17f, 0.14f, 0.17f), default(Vector3), false);
                    Art.Part("TR", cube, Art.silverMat, spin, new Vector3(0.2f, 0.3f, 0f), new Vector3(0.17f, 0.14f, 0.17f), default(Vector3), false);
                    haloMat = Art.haloRed;
                    break;
                case ColType.Shield:
                    Art.Part("Plate", cube, Art.shieldPlateMat, spin, Vector3.zero, new Vector3(0.5f, 0.5f, 0.1f), new Vector3(0f, 0f, 45f), false);
                    Art.Part("Core", cube, Art.whiteGlowMat, spin, Vector3.zero, new Vector3(0.22f, 0.22f, 0.14f), new Vector3(0f, 0f, 45f), false);
                    haloMat = Art.haloCyan;
                    break;
                case ColType.Double:
                    Art.Part("Big", cyl, Art.orangeGlowMat, spin, Vector3.zero, new Vector3(0.72f, 0.06f, 0.72f), new Vector3(90f, 0f, 0f), false);
                    Art.Part("Small", cyl, Art.goldMat, spin, new Vector3(0f, 0f, -0.06f), new Vector3(0.46f, 0.06f, 0.46f), new Vector3(90f, 0f, 0f), false);
                    Art.Part("Dot", cube, Art.goldDarkMat, spin, new Vector3(0f, 0f, -0.1f), new Vector3(0.14f, 0.14f, 0.06f), default(Vector3), false);
                    haloMat = Art.haloOrange;
                    break;
                case ColType.Dash:
                    Art.Part("Arrow1", Art.Cone, Art.greenGlowMat, spin, new Vector3(0f, 0f, 0.12f), new Vector3(0.34f, 0.5f, 0.34f), new Vector3(90f, 0f, 0f), false);
                    Art.Part("Arrow2", Art.Cone, Art.greenGlowMat, spin, new Vector3(0f, 0f, -0.18f), new Vector3(0.34f, 0.5f, 0.34f), new Vector3(90f, 0f, 0f), false);
                    haloMat = Art.haloGreen;
                    break;
            }
            if (haloMat != null)
                halo = Art.Part("Halo", quad, haloMat, root, Vector3.zero, Vector3.one * 1.7f, default(Vector3), false).transform;

            var col = new Collectible { t = root, spin = spin, halo = halo, type = type, baseY = y, phase = Random.Range(0f, 6.28f) };
            c.cols.Add(col);
            return col;
        }
    }
}
