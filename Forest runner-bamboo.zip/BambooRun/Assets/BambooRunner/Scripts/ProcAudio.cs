using System.Collections.Generic;
using UnityEngine;

namespace BambooRunner
{
    public enum Sfx { Coin, Gem, Jump, Land, Slide, Lane, Crash, Power, ShieldBreak, Reward, Step, Click, Revive }

    /// <summary>
    /// All sounds are synthesized at startup (no audio files needed):
    /// sound effects, a pentatonic bamboo-marimba music loop and a forest ambience loop.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager I;
        const int SR = 44100;

        readonly Dictionary<Sfx, AudioClip> clips = new Dictionary<Sfx, AudioClip>();
        AudioSource[] pool;
        int next;
        AudioSource music, ambience;
        public bool Muted { get; private set; }
        const float SfxVol = 0.85f, MusicVol = 0.32f, AmbVol = 0.55f;

        void Awake()
        {
            I = this;
            pool = new AudioSource[10];
            for (int i = 0; i < pool.Length; i++)
            {
                var s = gameObject.AddComponent<AudioSource>();
                s.playOnAwake = false; s.spatialBlend = 0f;
                pool[i] = s;
            }
            music = gameObject.AddComponent<AudioSource>();
            music.loop = true; music.playOnAwake = false; music.spatialBlend = 0f; music.volume = MusicVol;
            ambience = gameObject.AddComponent<AudioSource>();
            ambience.loop = true; ambience.playOnAwake = false; ambience.spatialBlend = 0f; ambience.volume = AmbVol;
            Build();
        }

        public void StartLoops()
        {
            if (!music.isPlaying) music.Play();
            if (!ambience.isPlaying) ambience.Play();
        }

        public void SetMuted(bool m)
        {
            Muted = m;
            music.mute = m; ambience.mute = m;
        }

        public void Play(Sfx s, float pitch = 1f, float vol = 1f)
        {
            if (Muted) return;
            AudioClip c;
            if (!clips.TryGetValue(s, out c)) return;
            var src = pool[next];
            next = (next + 1) % pool.Length;
            src.clip = c;
            src.pitch = pitch;
            src.volume = Mathf.Clamp01(vol * SfxVol);
            src.Play();
        }

        // ------------------------------------------------------------------ synthesis
        void Build()
        {
            var r = new System.Random(4242);
            clips[Sfx.Coin] = Mk("coin", Coin(), 0.8f);
            clips[Sfx.Gem] = Mk("gem", Gem(), 0.8f);
            clips[Sfx.Jump] = Mk("jump", Jump(r), 0.7f);
            clips[Sfx.Land] = Mk("land", Land(r), 0.85f);
            clips[Sfx.Slide] = Mk("slide", Slide(r), 0.7f);
            clips[Sfx.Lane] = Mk("lane", Lane(r), 0.5f);
            clips[Sfx.Crash] = Mk("crash", Crash(r), 0.95f);
            clips[Sfx.Power] = Mk("power", Power(), 0.8f);
            clips[Sfx.ShieldBreak] = Mk("shieldbreak", ShieldBreak(r), 0.8f);
            clips[Sfx.Reward] = Mk("reward", Reward(), 0.8f);
            clips[Sfx.Step] = Mk("step", Step(r), 0.7f);
            clips[Sfx.Click] = Mk("click", Click(), 0.6f);
            clips[Sfx.Revive] = Mk("revive", Revive(), 0.8f);
            music.clip = Mk("music", Music(r), 0.55f);
            ambience.clip = Mk("ambience", Ambience(r), 0.5f);
        }

        static float[] Buf(float sec) { return new float[Mathf.CeilToInt(sec * SR)]; }
        static float Nz(System.Random r) { return (float)(r.NextDouble() * 2.0 - 1.0); }

        static AudioClip Mk(string name, float[] d, float peak)
        {
            float mx = 0.0001f;
            for (int i = 0; i < d.Length; i++) { float a = Mathf.Abs(d[i]); if (a > mx) mx = a; }
            float g = peak / mx;
            for (int i = 0; i < d.Length; i++) d[i] *= g;
            var c = AudioClip.Create(name, d.Length, 1, SR, false);
            c.SetData(d, 0);
            return c;
        }

        // additive decaying tone with a few harmonics
        static void Tone(float[] b, float start, float dur, float freq, float amp, float decay, float h2 = 0.3f, float h3 = 0.1f)
        {
            int s0 = (int)(start * SR), n = (int)(dur * SR);
            for (int i = 0; i < n && s0 + i < b.Length; i++)
            {
                float t = (float)i / SR;
                float env = Mathf.Exp(-t * decay) * Mathf.Min(1f, t / 0.004f) * Mathf.Clamp01((dur - t) / 0.02f);
                float ph = 2f * Mathf.PI * freq * t;
                float s = Mathf.Sin(ph) + h2 * Mathf.Sin(2f * ph) + h3 * Mathf.Sin(3f * ph);
                b[s0 + i] += s * env * amp;
            }
        }

        static void Sweep(float[] b, float start, float dur, float f0, float f1, float amp, float decay)
        {
            int s0 = (int)(start * SR), n = (int)(dur * SR);
            float ph = 0f;
            for (int i = 0; i < n && s0 + i < b.Length; i++)
            {
                float t = (float)i / SR;
                float f = Mathf.Lerp(f0, f1, (float)i / n);
                ph += 2f * Mathf.PI * f / SR;
                float env = Mathf.Exp(-t * decay) * Mathf.Min(1f, t / 0.003f) * Mathf.Clamp01((dur - t) / 0.01f);
                b[s0 + i] += Mathf.Sin(ph) * env * amp;
            }
        }

        static void Noise(float[] b, System.Random r, float start, float dur, float amp, float decay, float lp)
        {
            int s0 = (int)(start * SR), n = (int)(dur * SR);
            float y = 0f;
            for (int i = 0; i < n && s0 + i < b.Length; i++)
            {
                float t = (float)i / SR;
                y += (Nz(r) - y) * lp;
                b[s0 + i] += y * Mathf.Exp(-t * decay) * amp;
            }
        }

        static float[] Coin()
        {
            var b = Buf(0.5f);
            Tone(b, 0f, 0.14f, 1318.5f, 0.6f, 16f, 0.25f, 0.08f);
            Tone(b, 0.07f, 0.42f, 1975.5f, 0.6f, 8f, 0.2f, 0.05f);
            return b;
        }

        static float[] Gem()
        {
            var b = Buf(0.8f);
            float[] f = { 1046.5f, 1318.5f, 1568f, 2093f, 2637f };
            for (int i = 0; i < f.Length; i++) Tone(b, i * 0.055f, 0.5f, f[i], 0.45f, 7f, 0.25f, 0.05f);
            return b;
        }

        static float[] Jump(System.Random r)
        {
            var b = Buf(0.3f);
            Sweep(b, 0f, 0.26f, 260f, 640f, 0.6f, 5f);
            Noise(b, r, 0f, 0.15f, 0.25f, 14f, 0.35f);
            return b;
        }

        static float[] Land(System.Random r)
        {
            var b = Buf(0.25f);
            Sweep(b, 0f, 0.18f, 150f, 55f, 0.9f, 16f);
            Noise(b, r, 0f, 0.12f, 0.4f, 25f, 0.15f);
            return b;
        }

        static float[] Slide(System.Random r)
        {
            var b = Buf(0.6f);
            float lp1 = 0f, lp2 = 0f;
            for (int i = 0; i < b.Length; i++)
            {
                float t = (float)i / b.Length;
                float n = Nz(r);
                lp1 += (n - lp1) * 0.30f;
                lp2 += (n - lp2) * 0.04f;
                float env = Mathf.Sqrt(Mathf.Sin(Mathf.PI * t)) * (1f - t * 0.4f);
                b[i] = (lp1 - lp2) * env * 1.6f;
            }
            return b;
        }

        static float[] Lane(System.Random r)
        {
            var b = Buf(0.16f);
            float lp = 0f;
            for (int i = 0; i < b.Length; i++)
            {
                float t = (float)i / b.Length;
                lp += (Nz(r) - lp) * 0.35f;
                b[i] = lp * Mathf.Sin(Mathf.PI * t);
            }
            return b;
        }

        static float[] Crash(System.Random r)
        {
            var b = Buf(1f);
            Noise(b, r, 0f, 0.9f, 1.0f, 5f, 0.30f);
            Sweep(b, 0f, 0.8f, 130f, 38f, 0.9f, 4f);
            Noise(b, r, 0f, 0.06f, 1.0f, 40f, 0.9f);   // wood crack
            Noise(b, r, 0.08f, 0.05f, 0.7f, 40f, 0.8f);
            return b;
        }

        static float[] Power()
        {
            var b = Buf(0.8f);
            float[] f = { 523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f };
            for (int i = 0; i < f.Length; i++) Tone(b, i * 0.07f, 0.45f, f[i], 0.45f, 6f, 0.35f, 0.1f);
            return b;
        }

        static float[] ShieldBreak(System.Random r)
        {
            var b = Buf(0.5f);
            Sweep(b, 0f, 0.4f, 1800f, 260f, 0.5f, 6f);
            Noise(b, r, 0f, 0.3f, 0.5f, 9f, 0.8f);
            return b;
        }

        static float[] Reward()
        {
            var b = Buf(1.3f);
            Tone(b, 0f, 0.5f, 523.25f, 0.4f, 3.5f, 0.3f, 0.1f);
            Tone(b, 0.12f, 0.5f, 659.25f, 0.4f, 3.5f, 0.3f, 0.1f);
            Tone(b, 0.24f, 0.6f, 783.99f, 0.4f, 3f, 0.3f, 0.1f);
            Tone(b, 0.40f, 0.9f, 1046.5f, 0.45f, 2.5f, 0.3f, 0.1f);
            Tone(b, 0.40f, 0.9f, 1318.5f, 0.25f, 2.5f, 0.3f, 0.1f);
            return b;
        }

        static float[] Step(System.Random r)
        {
            var b = Buf(0.1f);
            Sweep(b, 0f, 0.08f, 170f, 90f, 0.6f, 40f);
            Noise(b, r, 0f, 0.06f, 0.35f, 45f, 0.25f);
            return b;
        }

        static float[] Click()
        {
            var b = Buf(0.08f);
            Tone(b, 0f, 0.06f, 900f, 0.5f, 55f, 0.2f, 0f);
            return b;
        }

        static float[] Revive()
        {
            var b = Buf(0.9f);
            Sweep(b, 0f, 0.5f, 200f, 900f, 0.4f, 2f);
            Tone(b, 0.35f, 0.5f, 880f, 0.4f, 4f);
            Tone(b, 0.45f, 0.45f, 1318.5f, 0.35f, 4f);
            return b;
        }

        // relaxed bamboo-marimba melody in D major pentatonic over a soft drone, 100 bpm
        static float[] Music(System.Random r)
        {
            float step = 60f / 100f / 2f;
            int steps = 64;
            float loop = steps * step;
            var mel = Buf(loop);
            var bass = Buf(loop);
            var perc = Buf(loop);
            float[] scale = { 293.66f, 329.63f, 369.99f, 440f, 493.88f, 587.33f, 659.25f, 739.99f, 880f };

            int[] motif = new int[16];
            int idx = 3;
            for (int i = 0; i < 16; i++)
            {
                if (r.NextDouble() < 0.28) motif[i] = -1;
                else
                {
                    idx = Mathf.Clamp(idx + r.Next(-2, 3), 0, 8);
                    motif[i] = idx;
                }
            }
            for (int s = 0; s < steps; s++)
            {
                int m = motif[s % 16];
                if (m >= 0 && s >= 32 && r.NextDouble() < 0.25) m = Mathf.Clamp(m + r.Next(-1, 2), 0, 8);
                if (m >= 0) Tone(mel, s * step, 0.55f, scale[m], 0.5f, 6f, 0.25f, 0.08f);
                if (s % 2 == 0) Tone(perc, s * step, 0.08f, (s % 4 == 0) ? 1100f : 820f, 0.18f, 45f, 0.5f, 0f);
                if (s % 8 == 4) Sweep(perc, s * step, 0.25f, 120f, 55f, 0.7f, 12f);
            }
            float[] bf = { 73.42f, 55f, 61.74f, 55f };
            for (int k = 0; k < 8; k++)
                Tone(bass, k * 8 * step, 8 * step * 0.97f, bf[k % 4], 0.55f, 0.9f, 0.4f, 0.1f);

            var outb = new float[mel.Length];
            int d = (int)(step * 1.5f * SR);
            for (int i = 0; i < outb.Length; i++)
            {
                float e = mel[i]
                          + 0.33f * mel[(i - d + outb.Length) % outb.Length]
                          + 0.16f * mel[(i - 2 * d + outb.Length * 2) % outb.Length];
                outb[i] = e + bass[i] * 0.55f + perc[i] * 0.5f;
            }
            return outb;
        }

        // forest ambience: wind in the canopy, rustling leaves, birds and hollow bamboo knocks
        static float[] Ambience(System.Random r)
        {
            float len = 14f;
            int N = Mathf.CeilToInt(len * SR);
            int X = SR; // 1s crossfade for a seamless loop
            var raw = new float[N + X];
            var rustle = new float[N + X];
            float lp = 0f, lp2 = 0f;
            for (int i = 0; i < raw.Length; i++)
            {
                float n = Nz(r);
                lp += (n - lp) * 0.02f;
                lp2 += (n - lp2) * 0.25f;
                raw[i] = lp * 3.2f;
                rustle[i] = (lp2 - lp) * 0.12f;
            }
            var b = new float[N];
            for (int i = 0; i < N; i++)
            {
                float w = raw[i], ru = rustle[i];
                if (i < X)
                {
                    float a = (float)i / X;
                    w = raw[i] * a + raw[N + i] * (1f - a);
                    ru = rustle[i] * a + rustle[N + i] * (1f - a);
                }
                float t = (float)i / SR;
                float mod = 0.65f + 0.35f * Mathf.Sin(2f * Mathf.PI * (3f / len) * t);
                float renv = Mathf.Pow(Mathf.Max(0f, Mathf.Sin(2f * Mathf.PI * (7f / len) * t + 1f)), 3f);
                b[i] = w * mod + ru * renv;
            }
            // birds
            for (int k = 0; k < 6; k++)
            {
                float t0 = 0.6f + (float)r.NextDouble() * (len - 2.5f);
                float f0 = 2300f + (float)r.NextDouble() * 1400f;
                int notes = 2 + r.Next(0, 3);
                for (int q = 0; q < notes; q++)
                    Sweep(b, t0 + q * 0.11f, 0.08f, f0, f0 * 1.3f, 0.9f, 12f);
            }
            // hollow bamboo knocks
            for (int k = 0; k < 4; k++)
            {
                float t0 = 1f + (float)r.NextDouble() * (len - 3f);
                float f = 360f + (float)r.NextDouble() * 90f;
                Tone(b, t0, 0.28f, f, 1.1f, 26f, 0.9f, 0.25f);
                Tone(b, t0 + 0.13f, 0.28f, f * 1.12f, 0.9f, 26f, 0.9f, 0.25f);
            }
            return b;
        }
    }
}
