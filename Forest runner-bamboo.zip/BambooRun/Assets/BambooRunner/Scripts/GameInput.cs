using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace BambooRunner
{
    public enum SwipeDir { None, Left, Right, Up, Down }

    /// <summary>
    /// Boots the game automatically when you press Play (in any scene).
    /// </summary>
    public static class Bootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if (GameObject.Find("BambooRunner_Game") != null) return;
            var go = new GameObject("BambooRunner_Game");
            go.AddComponent<GameManager>();
        }
    }

    /// <summary>
    /// Works with both the old Input Manager and the new Input System package.
    /// Keyboard: A/D or arrows, W/Up/Space, S/Down. Touch / mouse: swipe.
    /// </summary>
    public static class GameInput
    {
        static bool tracking;
        static Vector2 startPos;

        public static void ResetSwipe() { tracking = false; }

        public static SwipeDir Poll()
        {
            SwipeDir k = Keys();
            if (k != SwipeDir.None) return k;
            return Swipe();
        }

        static SwipeDir Keys()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            if (k == null) return SwipeDir.None;
            if (k.leftArrowKey.wasPressedThisFrame || k.aKey.wasPressedThisFrame) return SwipeDir.Left;
            if (k.rightArrowKey.wasPressedThisFrame || k.dKey.wasPressedThisFrame) return SwipeDir.Right;
            if (k.upArrowKey.wasPressedThisFrame || k.wKey.wasPressedThisFrame || k.spaceKey.wasPressedThisFrame) return SwipeDir.Up;
            if (k.downArrowKey.wasPressedThisFrame || k.sKey.wasPressedThisFrame) return SwipeDir.Down;
            return SwipeDir.None;
#else
            if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKeyDown(KeyCode.A)) return SwipeDir.Left;
            if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKeyDown(KeyCode.D)) return SwipeDir.Right;
            if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Space)) return SwipeDir.Up;
            if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) return SwipeDir.Down;
            return SwipeDir.None;
#endif
        }

        public static bool Confirm()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            return k != null && (k.spaceKey.wasPressedThisFrame || k.enterKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return);
#endif
        }

        public static bool PausePressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            return k != null && (k.escapeKey.wasPressedThisFrame || k.pKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P);
#endif
        }

        public static bool MutePressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            return k != null && k.mKey.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.M);
#endif
        }

        public static bool RetryPressed()
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            return k != null && k.rKey.wasPressedThisFrame;
#else
            return Input.GetKeyDown(KeyCode.R);
#endif
        }

        /// <summary>Pointer (mouse / touch) went down this frame. pos = screen pixels, origin bottom-left.</summary>
        public static bool PointerDown(out Vector2 pos)
        {
#if ENABLE_INPUT_SYSTEM
            var m = Mouse.current;
            if (m != null && m.leftButton.wasPressedThisFrame) { pos = m.position.ReadValue(); return true; }
            var t = Touchscreen.current;
            if (t != null && t.primaryTouch.press.wasPressedThisFrame) { pos = t.primaryTouch.position.ReadValue(); return true; }
            pos = Vector2.zero; return false;
#else
            if (Input.GetMouseButtonDown(0)) { pos = Input.mousePosition; return true; }
            pos = Vector2.zero; return false;
#endif
        }

        static bool PointerHeld(out Vector2 pos)
        {
#if ENABLE_INPUT_SYSTEM
            var m = Mouse.current;
            if (m != null && m.leftButton.isPressed) { pos = m.position.ReadValue(); return true; }
            var t = Touchscreen.current;
            if (t != null && t.primaryTouch.press.isPressed) { pos = t.primaryTouch.position.ReadValue(); return true; }
            pos = Vector2.zero; return false;
#else
            if (Input.GetMouseButton(0)) { pos = Input.mousePosition; return true; }
            pos = Vector2.zero; return false;
#endif
        }

        static SwipeDir Swipe()
        {
            Vector2 p;
            if (PointerDown(out p)) { tracking = true; startPos = p; return SwipeDir.None; }
            if (!tracking) return SwipeDir.None;
            if (!PointerHeld(out p)) { tracking = false; return SwipeDir.None; }
            Vector2 d = p - startPos;
            float th = Mathf.Max(40f, Screen.height * 0.05f);
            if (d.magnitude > th)
            {
                tracking = false;
                if (Mathf.Abs(d.x) > Mathf.Abs(d.y)) return d.x > 0 ? SwipeDir.Right : SwipeDir.Left;
                return d.y > 0 ? SwipeDir.Up : SwipeDir.Down;
            }
            return SwipeDir.None;
        }
    }
}
